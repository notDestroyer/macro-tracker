# Setup: what only you can do

You need a computer for the one-time upload (a browser is enough; no command line required). Everything else is already written and tested.

## 1. GitHub (about 5 minutes)
1. Create a free account at github.com, then a **private** repository named `macro-tracker`.
2. Upload the contents of the zip (drag the unzipped folder into the repo page: "Add file" > "Upload files"). Commit to `main`.

## 2. Supabase (about 10 minutes)
1. Sign up at supabase.com and create a project. Pick the region closest to you. **Save the database password.**
2. Copy these three values:
   - Project reference: Project Settings > General > "Reference ID"
   - Access token: your avatar > Account Preferences > Access Tokens > Generate new token
   - Project URL and the publishable (anon) key: Project Settings > API Keys (needed for Milestone 2)
3. In GitHub: repo > Settings > Secrets and variables > Actions > New repository secret. Add:
   `SUPABASE_ACCESS_TOKEN`, `SUPABASE_PROJECT_REF`, `SUPABASE_DB_PASSWORD`.
4. In GitHub > Actions > "deploy-supabase" > Run workflow. It runs the 55 tests, applies the four migrations, then deploys the three functions. If any step fails, paste me the log.
   (Alternative without GitHub Actions: paste each file in `supabase/migrations/` into the Supabase SQL Editor in numeric order.)
5. Authentication > Sign In / Providers: keep Email enabled. Authentication > URL Configuration: set Site URL to your Cloudflare address once you have it (step 4).

## 3. Function secrets (about 5 minutes)
Supabase dashboard > Edge Functions > Secrets > add:
| Name | Value |
|---|---|
| `USDA_API_KEY` | free key from https://fdc.nal.usda.gov/api-key-signup (emailed instantly) |
| `OFF_USER_AGENT` | `MacroTracker/0.1 (your-email@example.com)` (Open Food Facts requires this) |
| `ALLOWED_ORIGIN` | your Cloudflare site address, e.g. `https://macro-tracker.pages.dev` (until then, leave unset) |

Never put these keys in GitHub or in the web page.

## 4. Cloudflare Pages (about 5 minutes)
1. Sign up at cloudflare.com > Workers & Pages > Create > Pages > Connect to Git > choose `macro-tracker`.
2. Build command: leave empty. Build output directory: `web`. Production branch: `main`.
3. Phase 1 is a single static file, so there is no React or Vite build. Cloudflare serves it as is.
4. For staging, create a branch named `staging`; Cloudflare gives it its own preview address, so the live page is never touched.

## 5. Live integration test (about 2 minutes, needs Node 22)
```
USDA_API_KEY=your_key OFF_USER_AGENT="MacroTracker/0.1 (you@example.com)" node scripts/smoke.mjs
```
Paste me the output. Until you do, the USDA and Open Food Facts adapters are written and unit-tested but **not verified against live responses**.

## Costs and limits in this milestone
- Supabase Free: $0, but it has no backups and pauses after a week idle. **Upgrade to Pro ($25/month) before you rely on your data.** This is your call.
- USDA and Open Food Facts: $0. The functions cap outside calls (USDA 900/hour, Open Food Facts 8 searches and 12 barcode reads per minute) and each user to 40 online searches and 200 barcode lookups per day.
- No AI is called yet, so no AI cost. Budgets and alerts arrive with Milestone 3.
