-- 0001: core schema. Row Level Security is enabled on every table in this file.
-- Convention: a missing food_nutrients row (or a missing key in log_entries.nutrients) means UNKNOWN. Zero is stored only when a source reported zero.
create extension if not exists pg_trgm with schema extensions;
create extension if not exists unaccent with schema extensions;

create table public.sources (
  id smallint generated always as identity primary key,
  key text not null unique,
  name text not null,
  tier smallint not null check (tier between 1 and 7),
  license text not null,
  attribution_text text,
  url text,
  cache_ttl_days int check (cache_ttl_days is null or cache_ttl_days > 0)
);

create table public.nutrients (
  id smallint primary key,
  key text not null unique,
  name text not null,
  unit text not null check (unit in ('g', 'mg', 'ug', 'kcal'))
);

create table public.foods (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(name) between 1 and 300),
  search_text text not null,
  brand text,
  manufacturer text,
  category text,
  kind text not null check (kind in ('generic', 'branded', 'restaurant', 'recipe', 'estimate', 'user')),
  prep text,
  state text check (state in ('raw', 'cooked', 'dry', 'prepared', 'as_sold')),
  basis text not null default 'g' check (basis in ('g', 'ml')),
  source_id smallint not null references public.sources (id),
  source_ref text not null,
  fetched_at timestamptz not null default now(),
  verified_at timestamptz,
  verification text not null default 'unverified' check (verification in ('verified', 'imported', 'unverified', 'flagged')),
  confidence text not null check (confidence in ('high', 'moderate', 'low')),
  duplicate_of uuid references public.foods (id),
  owner_id uuid references auth.users (id) on delete cascade,
  attrs jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (source_id, source_ref)
);
create index foods_search_trgm on public.foods using gin (search_text extensions.gin_trgm_ops);
create index foods_brand_idx on public.foods (lower(brand));
create index foods_owner_idx on public.foods (owner_id) where owner_id is not null;
create index foods_duplicate_idx on public.foods (duplicate_of) where duplicate_of is not null;

create table public.food_aliases (
  food_id uuid not null references public.foods (id) on delete cascade,
  alias text not null,
  primary key (food_id, alias)
);

create table public.food_nutrients (
  food_id uuid not null references public.foods (id) on delete cascade,
  nutrient_id smallint not null references public.nutrients (id),
  per100g numeric not null check (per100g >= 0 and per100g <= 1000000),
  reported_amount numeric,
  reported_unit text,
  reported_basis text,
  derivation text not null default 'reported' check (derivation in ('reported', 'calculated', 'estimated')),
  primary key (food_id, nutrient_id)
);
comment on table public.food_nutrients is 'per100g is per 100 g, or per 100 ml when foods.basis = ml. Missing row = UNKNOWN.';

create table public.serving_sizes (
  id uuid primary key default gen_random_uuid(),
  food_id uuid not null references public.foods (id) on delete cascade,
  label text not null,
  amount numeric not null default 1 check (amount > 0),
  unit text not null,
  modifier text,
  grams numeric check (grams > 0),
  ml numeric check (ml > 0),
  state text check (state in ('raw', 'cooked', 'dry', 'prepared', 'as_sold')),
  is_default boolean not null default false,
  source_id smallint references public.sources (id),
  conversion_confidence text not null default 'moderate' check (conversion_confidence in ('high', 'moderate', 'low')),
  check (grams is not null or ml is not null)
);
create index serving_sizes_food_idx on public.serving_sizes (food_id);

create table public.barcodes (
  gtin14 text not null check (gtin14 ~ '^[0-9]{14}$'),
  food_id uuid not null references public.foods (id) on delete cascade,
  original text not null,
  type text,
  verification text not null default 'unverified' check (verification in ('verified', 'unverified')),
  primary key (gtin14, food_id)
);
create index barcodes_food_idx on public.barcodes (food_id);

create table public.user_corrections (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users (id) on delete cascade,
  food_id uuid not null references public.foods (id) on delete cascade,
  nutrient_id smallint references public.nutrients (id),
  original_value numeric,
  corrected_value numeric,
  kind text not null check (kind in ('nutrient', 'serving', 'name', 'flag')),
  scope text not null default 'personal' check (scope in ('personal', 'review_requested')),
  note text,
  created_at timestamptz not null default now()
);
comment on table public.user_corrections is 'Personal overlay. Never edits global food records.';

create table public.recipes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users (id) on delete cascade,
  name text not null,
  instructions text,
  servings numeric not null check (servings > 0),
  total_grams numeric check (total_grams > 0),
  created_at timestamptz not null default now()
);
create table public.recipe_ingredients (
  recipe_id uuid not null references public.recipes (id) on delete cascade,
  position int not null,
  food_id uuid not null references public.foods (id),
  grams numeric not null check (grams > 0),
  state text,
  primary key (recipe_id, position)
);

create table public.estimates (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users (id) on delete cascade,
  method text not null check (method in ('text', 'photo', 'label_ocr', 'restaurant_comparable')),
  items jsonb not null check (jsonb_typeof(items) = 'array'),
  confidence text not null check (confidence in ('high', 'moderate', 'low')),
  assumptions text,
  user_confirmed boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.log_entries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users (id) on delete cascade,
  logged_on date not null,
  meal text not null check (length(meal) between 1 and 40),
  name text not null,
  food_id uuid references public.foods (id) on delete set null,
  estimate_id uuid references public.estimates (id) on delete set null,
  legacy_ref text,
  legacy_id text,
  quantity numeric,
  unit_label text,
  grams numeric,
  nutrients jsonb not null check (jsonb_typeof(nutrients) = 'object'),
  provenance text not null check (provenance in ('verified', 'imported', 'ai_estimate', 'user', 'user_corrected', 'legacy_seed')),
  confidence text check (confidence in ('high', 'moderate', 'low')),
  created_at timestamptz not null default now()
);
comment on column public.log_entries.nutrients is 'Snapshot {nutrient_key: number}. Absent key = unknown. Refreshing a source never changes history.';
create unique index log_entries_legacy_uq on public.log_entries (user_id, legacy_id); -- NULL legacy_id rows never collide; lets the importer upsert idempotently
create index log_entries_day_idx on public.log_entries (user_id, logged_on);

create table public.user_profiles (
  user_id uuid primary key default auth.uid() references auth.users (id) on delete cascade,
  profile jsonb not null,
  targets jsonb not null,
  updated_at timestamptz not null default now()
);
create table public.water_logs (
  user_id uuid not null default auth.uid() references auth.users (id) on delete cascade,
  day date not null,
  ml int not null check (ml >= 0),
  primary key (user_id, day)
);
create table public.quota_counters (
  key text not null,
  window_start timestamptz not null,
  count int not null default 0,
  primary key (key, window_start)
);

-- Row Level Security -------------------------------------------------------------------------
alter table public.sources enable row level security;
alter table public.nutrients enable row level security;
alter table public.foods enable row level security;
alter table public.food_aliases enable row level security;
alter table public.food_nutrients enable row level security;
alter table public.serving_sizes enable row level security;
alter table public.barcodes enable row level security;
alter table public.user_corrections enable row level security;
alter table public.recipes enable row level security;
alter table public.recipe_ingredients enable row level security;
alter table public.estimates enable row level security;
alter table public.log_entries enable row level security;
alter table public.user_profiles enable row level security;
alter table public.water_logs enable row level security;
alter table public.quota_counters enable row level security; -- no policies: reachable only through service-role functions

create policy sources_read on public.sources for select to authenticated using (true);
create policy nutrients_read on public.nutrients for select to authenticated using (true);

create policy foods_read on public.foods for select to authenticated using (owner_id is null or owner_id = auth.uid());
create policy foods_insert on public.foods for insert to authenticated with check (owner_id = auth.uid() and kind = 'user');
create policy foods_update on public.foods for update to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid() and kind = 'user');
create policy foods_delete on public.foods for delete to authenticated using (owner_id = auth.uid());

create policy aliases_read on public.food_aliases for select to authenticated
  using (exists (select 1 from public.foods f where f.id = food_id and (f.owner_id is null or f.owner_id = auth.uid())));
create policy barcodes_read on public.barcodes for select to authenticated
  using (exists (select 1 from public.foods f where f.id = food_id and (f.owner_id is null or f.owner_id = auth.uid())));
create policy nutrients_rows_read on public.food_nutrients for select to authenticated
  using (exists (select 1 from public.foods f where f.id = food_id and (f.owner_id is null or f.owner_id = auth.uid())));
create policy nutrients_rows_own on public.food_nutrients for all to authenticated
  using (exists (select 1 from public.foods f where f.id = food_id and f.owner_id = auth.uid()))
  with check (exists (select 1 from public.foods f where f.id = food_id and f.owner_id = auth.uid()));
create policy servings_read on public.serving_sizes for select to authenticated
  using (exists (select 1 from public.foods f where f.id = food_id and (f.owner_id is null or f.owner_id = auth.uid())));
create policy servings_own on public.serving_sizes for all to authenticated
  using (exists (select 1 from public.foods f where f.id = food_id and f.owner_id = auth.uid()))
  with check (exists (select 1 from public.foods f where f.id = food_id and f.owner_id = auth.uid()));

create policy own_rows on public.user_corrections for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy own_rows on public.recipes for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy own_rows on public.estimates for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy own_rows on public.log_entries for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy own_rows on public.user_profiles for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy own_rows on public.water_logs for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy own_ingredients on public.recipe_ingredients for all to authenticated
  using (exists (select 1 from public.recipes r where r.id = recipe_id and r.user_id = auth.uid()))
  with check (exists (select 1 from public.recipes r where r.id = recipe_id and r.user_id = auth.uid())
    and exists (select 1 from public.foods f where f.id = food_id and (f.owner_id is null or f.owner_id = auth.uid())));

-- Privileges: the app requires sign-in; reference data is read-only for users.
revoke all on all tables in schema public from anon;
revoke insert, update, delete, truncate on public.sources, public.nutrients, public.food_aliases, public.barcodes from authenticated;
revoke all on public.quota_counters from authenticated;
