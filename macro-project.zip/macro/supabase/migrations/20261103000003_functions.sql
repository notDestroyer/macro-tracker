-- 0003: search, ingestion, quota and food-bundle functions.

-- Local search: token match (any order) plus trigram similarity for misspellings. RLS applies (security invoker).
-- Scale note: fine into the low hundreds of thousands of rows. Beyond that, add a longest-token prefilter.
create or replace function public.search_foods(q text, lim int default 20, offs int default 0)
returns table (id uuid, name text, brand text, kind text, state text, prep text, basis text, verification text, confidence text,
               source_key text, tier smallint, kcal numeric, protein numeric, carbs numeric, fat numeric, score real)
language plpgsql stable security invoker set search_path = public, extensions
as $$
#variable_conflict use_column
declare
  s text;
  toks text[];
begin
  s := regexp_replace(lower(unaccent(left(btrim(coalesce(q, '')), 100))), '[^a-z0-9 ]+', ' ', 'g');
  s := btrim(regexp_replace(s, '\s+', ' ', 'g'));
  if length(s) < 2 then return; end if;
  toks := string_to_array(s, ' ');
  return query
  with hits as (
    select f.*,
           (select count(*) from unnest(toks) t where f.search_text like '%' || t || '%')::real / array_length(toks, 1) as cov,
           similarity(f.search_text, s) as sim
    from public.foods f
    where f.duplicate_of is null
      and (f.owner_id is null or f.owner_id = auth.uid())
      and (f.search_text % s or not exists (select 1 from unnest(toks) t where f.search_text not like '%' || t || '%'))
  ), ranked as (
    select h.*, src.key as skey, src.tier as stier,
           (h.cov * 2 + h.sim + case when h.search_text like s || '%' then 0.5 else 0 end - src.tier * 0.05)::real as sc
    from hits h join public.sources src on src.id = h.source_id
    order by sc desc, h.name
    limit greatest(1, least(coalesce(lim, 20), 50)) offset greatest(0, coalesce(offs, 0))
  )
  select r.id, r.name, r.brand, r.kind, r.state, r.prep, r.basis, r.verification, r.confidence, r.skey, r.stier,
         (select fn.per100g from public.food_nutrients fn join public.nutrients n on n.id = fn.nutrient_id where fn.food_id = r.id and n.key = 'energy_kcal'),
         (select fn.per100g from public.food_nutrients fn join public.nutrients n on n.id = fn.nutrient_id where fn.food_id = r.id and n.key = 'protein'),
         (select fn.per100g from public.food_nutrients fn join public.nutrients n on n.id = fn.nutrient_id where fn.food_id = r.id and n.key = 'carb_total'),
         (select fn.per100g from public.food_nutrients fn join public.nutrients n on n.id = fn.nutrient_id where fn.food_id = r.id and n.key = 'fat_total'),
         r.sc
  from ranked r
  order by r.sc desc, r.name;
end;
$$;
grant execute on function public.search_foods(text, int, int) to authenticated;

-- One food as the JSON shape the calculation engine expects ({basis, state, servings, nutrients, confidence, source}). RLS applies.
create or replace function public.get_food(p_id uuid)
returns jsonb
language sql stable security invoker set search_path = public
as $$
  select jsonb_build_object(
    'id', f.id, 'name', f.name, 'brand', f.brand, 'kind', f.kind, 'state', f.state, 'prep', f.prep, 'basis', f.basis,
    'verification', f.verification, 'confidence', f.confidence, 'fetched_at', f.fetched_at, 'attrs', f.attrs,
    'source', jsonb_build_object('key', s.key, 'name', s.name, 'tier', s.tier, 'license', s.license, 'attribution', s.attribution_text, 'ref', f.source_ref),
    'nutrients', coalesce((select jsonb_object_agg(n.key, fn.per100g) from public.food_nutrients fn join public.nutrients n on n.id = fn.nutrient_id where fn.food_id = f.id), '{}'::jsonb),
    'servings', coalesce((select jsonb_agg(jsonb_build_object('label', ss.label, 'amount', ss.amount, 'unit', ss.unit, 'modifier', ss.modifier,
        'grams', ss.grams, 'ml', ss.ml, 'state', ss.state, 'is_default', ss.is_default, 'confidence', ss.conversion_confidence)
        order by ss.is_default desc, ss.label) from public.serving_sizes ss where ss.food_id = f.id), '[]'::jsonb),
    'barcodes', coalesce((select jsonb_agg(b.gtin14) from public.barcodes b where b.food_id = f.id), '[]'::jsonb))
  from public.foods f join public.sources s on s.id = f.source_id
  where f.id = p_id;
$$;
grant execute on function public.get_food(uuid) to authenticated;

-- Atomic upsert of one normalized external food (service role only). Replaces nutrients, servings and barcodes for that record.
create or replace function public.ingest_food(p jsonb)
returns uuid
language plpgsql security definer set search_path = public, extensions
as $$
declare
  v_source smallint;
  v_id uuid;
  v_search text;
begin
  select id into v_source from public.sources where key = p ->> 'source_key';
  if v_source is null then raise exception 'unknown source: %', p ->> 'source_key'; end if;
  if coalesce(btrim(p ->> 'name'), '') = '' then raise exception 'name is required'; end if;
  if coalesce(p ->> 'source_ref', '') = '' then raise exception 'source_ref is required'; end if;

  v_search := btrim(regexp_replace(lower(unaccent(concat_ws(' ', p ->> 'name', p ->> 'brand', p ->> 'manufacturer',
      (select string_agg(a, ' ') from jsonb_array_elements_text(coalesce(p -> 'aliases', '[]'::jsonb)) a)))), '[^a-z0-9 ]+', ' ', 'g'));

  insert into public.foods (name, search_text, brand, manufacturer, category, kind, prep, state, basis, source_id, source_ref,
                            fetched_at, verification, confidence, attrs)
  values (left(p ->> 'name', 300), v_search, nullif(p ->> 'brand', ''), nullif(p ->> 'manufacturer', ''), nullif(p ->> 'category', ''),
          p ->> 'kind', nullif(p ->> 'prep', ''), nullif(p ->> 'state', ''), coalesce(p ->> 'basis', 'g'), v_source, p ->> 'source_ref',
          coalesce((p ->> 'fetched_at')::timestamptz, now()), p ->> 'verification', p ->> 'confidence', coalesce(p -> 'attrs', '{}'::jsonb))
  on conflict (source_id, source_ref) do update set
    name = excluded.name, search_text = excluded.search_text, brand = excluded.brand, manufacturer = excluded.manufacturer,
    category = excluded.category, kind = excluded.kind, prep = excluded.prep, state = excluded.state, basis = excluded.basis,
    fetched_at = excluded.fetched_at, verification = excluded.verification, confidence = excluded.confidence,
    attrs = excluded.attrs, updated_at = now()
  returning id into v_id;

  delete from public.food_nutrients where food_id = v_id;
  insert into public.food_nutrients (food_id, nutrient_id, per100g, reported_amount, reported_unit, reported_basis, derivation)
  select v_id, n.id, (x ->> 'per100g')::numeric, nullif(x ->> 'reported_amount', '')::numeric, x ->> 'reported_unit',
         x ->> 'reported_basis', coalesce(x ->> 'derivation', 'reported')
  from jsonb_array_elements(coalesce(p -> 'nutrients', '[]'::jsonb)) x
  join public.nutrients n on n.key = x ->> 'key';

  delete from public.serving_sizes where food_id = v_id;
  insert into public.serving_sizes (food_id, label, amount, unit, modifier, grams, ml, state, is_default, source_id, conversion_confidence)
  select v_id, coalesce(nullif(x ->> 'label', ''), x ->> 'unit'), coalesce((x ->> 'amount')::numeric, 1), x ->> 'unit',
         nullif(x ->> 'modifier', ''), nullif(x ->> 'grams', '')::numeric, nullif(x ->> 'ml', '')::numeric, nullif(x ->> 'state', ''),
         coalesce((x ->> 'is_default')::boolean, false), v_source, coalesce(x ->> 'confidence', 'moderate')
  from jsonb_array_elements(coalesce(p -> 'servings', '[]'::jsonb)) x
  where coalesce(nullif(x ->> 'grams', '')::numeric, nullif(x ->> 'ml', '')::numeric, 0) > 0;

  insert into public.barcodes (gtin14, food_id, original, type, verification)
  select x ->> 'gtin14', v_id, x ->> 'original', x ->> 'type', 'unverified'
  from jsonb_array_elements(coalesce(p -> 'barcodes', '[]'::jsonb)) x
  where (x ->> 'gtin14') ~ '^[0-9]{14}$'
  on conflict do nothing;

  delete from public.food_aliases where food_id = v_id;
  insert into public.food_aliases (food_id, alias)
  select distinct v_id, a from jsonb_array_elements_text(coalesce(p -> 'aliases', '[]'::jsonb)) a;

  return v_id;
end;
$$;
revoke all on function public.ingest_food(jsonb) from public, anon, authenticated;
grant execute on function public.ingest_food(jsonb) to service_role;

-- Fixed-window counter for rate limits and budgets. Returns false once the limit for the current window is exceeded (service role only).
create or replace function public.consume_quota(p_key text, p_limit int, p_window_seconds int)
returns boolean
language plpgsql security definer set search_path = public
as $$
declare
  w timestamptz := to_timestamp(floor(extract(epoch from now()) / p_window_seconds) * p_window_seconds);
  c int;
begin
  insert into public.quota_counters as qc (key, window_start, count) values (p_key, w, 1)
  on conflict (key, window_start) do update set count = qc.count + 1
  returning qc.count into c;
  if random() < 0.01 then delete from public.quota_counters where window_start < now() - interval '2 days'; end if;
  return c <= p_limit;
end;
$$;
revoke all on function public.consume_quota(text, int, int) from public, anon, authenticated;
grant execute on function public.consume_quota(text, int, int) to service_role;
