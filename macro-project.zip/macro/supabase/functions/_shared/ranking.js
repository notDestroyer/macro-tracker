// Ranks external candidates before ingestion. Local ranking happens in SQL (search_foods).
import { normalizeText } from './text.js';
import { completeness } from './discrepancy.js';

/** candidate: { name, brand, kind, tier, nutrients } */
export function scoreCandidate(query, c) {
  const toks = normalizeText(query).split(' ').filter(Boolean);
  if (!toks.length) return 0;
  const name = normalizeText(c.name), brand = normalizeText(c.brand || '');
  const hay = `${name} ${brand}`.trim();
  const words = hay.split(' ');
  const hit = (t) => words.some((w) => w === t || w.startsWith(t));
  const cov = toks.filter(hit).length / toks.length;
  let s = cov * 2;
  if (cov < 1) s *= 0.4;
  if (name === toks.join(' ')) s += 2;
  else if (name.startsWith(toks.join(' '))) s += 1;
  const brandHit = brand && toks.some((t) => brand.split(' ').some((w) => w.startsWith(t)));
  if (c.kind === 'branded') s += brandHit ? 1 : -0.3;
  else s += 0.4;
  s += completeness(c.nutrients) * 0.5 + (8 - (c.tier ?? 7)) * 0.1 - name.length * 0.002;
  return s;
}
export const rankCandidates = (query, list) => list.map((c) => ({ c, s: scoreCandidate(query, c) })).sort((a, b) => b.s - a.s).map((x) => x.c);
