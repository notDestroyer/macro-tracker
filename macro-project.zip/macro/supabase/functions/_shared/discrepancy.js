// Discrepancy detection between two candidate records for the same food. Never averages: picks one winner, keeps the other as an alternate.
const KEY = ['energy_kcal', 'protein', 'fat_total', 'carb_total', 'fiber', 'sugars_total', 'sodium', 'fat_sat'];
export const completeness = (n = {}) => KEY.filter((k) => n[k] != null).length / KEY.length;

/** a, b: { basis, state, prep, nutrients: {key: per100} }. Thresholds are tunable. */
export function compareFoods(a, b, { kcalPct = 0.15, kcalAbs = 10, macroAbs = 3, macroPct = 0.2 } = {}) {
  if ((a.basis || 'g') !== (b.basis || 'g')) return { comparable: false, reason: 'different basis (g vs ml)' };
  if (a.state && b.state && a.state !== b.state) return { comparable: false, reason: `different state (${a.state} vs ${b.state})` };
  if (a.prep && b.prep && a.prep !== b.prep) return { comparable: false, reason: `different preparation (${a.prep} vs ${b.prep})` };
  const conflicts = [];
  const ka = a.nutrients.energy_kcal, kb = b.nutrients.energy_kcal;
  if (ka != null && kb != null) {
    const d = Math.abs(ka - kb);
    if (d > kcalAbs && d / Math.max(ka, kb) > kcalPct) conflicts.push({ key: 'energy_kcal', a: ka, b: kb });
  }
  for (const k of ['protein', 'carb_total', 'fat_total']) {
    const x = a.nutrients[k], y = b.nutrients[k];
    if (x == null || y == null) continue;
    const d = Math.abs(x - y);
    if (d > Math.max(macroAbs, macroPct * Math.max(x, y))) conflicts.push({ key: k, a: x, b: y });
  }
  return { comparable: true, conflicts };
}

/** Lower tier wins; then more complete; then more recently fetched. */
export function pickWinner(a, b) {
  if (a.tier !== b.tier) return a.tier < b.tier ? a : b;
  const ca = completeness(a.nutrients), cb = completeness(b.nutrients);
  if (ca !== cb) return ca > cb ? a : b;
  return new Date(a.fetched_at || 0) >= new Date(b.fetched_at || 0) ? a : b;
}
