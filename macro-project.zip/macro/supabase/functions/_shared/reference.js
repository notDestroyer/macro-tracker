// Reference data. Single source of truth: scripts/gen-sql.mjs turns this into a migration, and tests keep them in sync.
// Nutrient ids are this project's own (array order). Source-specific ids are mapped in nutrients.js.
export const NUTRIENTS = [
  ['energy_kcal', 'Energy', 'kcal'], ['protein', 'Protein', 'g'], ['fat_total', 'Total fat', 'g'],
  ['carb_total', 'Carbohydrate, total', 'g'], ['fiber', 'Fiber, total dietary', 'g'],
  ['sugars_total', 'Sugars, total', 'g'], ['sugars_added', 'Sugars, added', 'g'],
  ['fat_sat', 'Saturated fat', 'g'], ['fat_mono', 'Monounsaturated fat', 'g'], ['fat_poly', 'Polyunsaturated fat', 'g'],
  ['fat_trans', 'Trans fat', 'g'], ['cholesterol', 'Cholesterol', 'mg'], ['sodium', 'Sodium', 'mg'],
  ['potassium', 'Potassium', 'mg'], ['calcium', 'Calcium', 'mg'], ['iron', 'Iron', 'mg'],
  ['magnesium', 'Magnesium', 'mg'], ['zinc', 'Zinc', 'mg'], ['phosphorus', 'Phosphorus', 'mg'],
  ['vit_a_rae', 'Vitamin A, RAE', 'ug'], ['vit_c', 'Vitamin C', 'mg'], ['vit_d', 'Vitamin D (D2 + D3)', 'ug'],
  ['vit_e', 'Vitamin E (alpha-tocopherol)', 'mg'], ['vit_k', 'Vitamin K', 'ug'], ['thiamin', 'Thiamin (B1)', 'mg'],
  ['riboflavin', 'Riboflavin (B2)', 'mg'], ['niacin', 'Niacin (B3)', 'mg'], ['vit_b6', 'Vitamin B6', 'mg'],
  ['vit_b12', 'Vitamin B12', 'ug'], ['folate_total', 'Folate, total', 'ug'], ['folate_dfe', 'Folate, DFE', 'ug'],
  ['choline', 'Choline, total', 'mg'], ['water', 'Water', 'g'], ['caffeine', 'Caffeine', 'mg'], ['alcohol', 'Alcohol, ethyl', 'g'],
].map(([key, name, unit], i) => ({ id: i + 1, key, name, unit }));

// [key, name, tier, license, attribution, url, cache_ttl_days]. Tier: 1 official label/restaurant ... 7 AI estimate.
export const SOURCES = [
  ['manufacturer_label', 'Manufacturer nutrition label', 1, 'label as printed', null, null, null],
  ['restaurant_doc', 'Official restaurant nutrition document', 1, 'published by restaurant', null, null, 90],
  ['usda_foundation', 'USDA FoodData Central: Foundation Foods', 2, 'CC0-1.0', 'U.S. Department of Agriculture, Agricultural Research Service. FoodData Central.', 'https://fdc.nal.usda.gov/', 180],
  ['usda_sr_legacy', 'USDA FoodData Central: SR Legacy', 2, 'CC0-1.0', 'U.S. Department of Agriculture, Agricultural Research Service. FoodData Central.', 'https://fdc.nal.usda.gov/', null],
  ['usda_fndds', 'USDA FoodData Central: Survey (FNDDS)', 3, 'CC0-1.0', 'U.S. Department of Agriculture, Agricultural Research Service. FoodData Central.', 'https://fdc.nal.usda.gov/', 180],
  ['usda_branded', 'USDA FoodData Central: Branded Foods', 3, 'CC0-1.0', 'U.S. Department of Agriculture, Agricultural Research Service. FoodData Central.', 'https://fdc.nal.usda.gov/', 30],
  ['off', 'Open Food Facts', 4, 'ODbL-1.0 (database), DbCL-1.0 (contents), CC-BY-SA-3.0 (images)', 'Open Food Facts contributors, ODbL. Crowdsourced; not verified by manufacturers.', 'https://world.openfoodfacts.org/', 14],
  ['user', 'User-created entry', 6, 'user data', null, null, null],
  ['legacy_seed', 'Phase 1 starter list (entered from memory, unverified)', 6, 'internal', null, null, null],
  ['ai', 'AI estimate', 7, 'internal', null, null, null],
].map(([key, name, tier, license, attribution_text, url, cache_ttl_days]) => ({ key, name, tier, license, attribution_text, url, cache_ttl_days }));

export const SOURCE_TIER = Object.fromEntries(SOURCES.map((s) => [s.key, s.tier]));
