// Text helpers shared by normalizers and search.
export function normalizeText(s) {
  return String(s ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim();
}
// State/prep are inferred only from explicit words. No match means unknown (null), never a guess.
export function inferState(desc) {
  const d = String(desc ?? '').toLowerCase();
  if (/\b(raw|uncooked)\b/.test(d)) return 'raw';
  if (/\b(cooked|boiled|baked|roasted|grilled|fried|steamed|braised|broiled|stewed|microwaved|pan-fried|scrambled|toasted)\b/.test(d)) return 'cooked';
  if (/\bdry\b/.test(d)) return 'dry';
  return null;
}
export function inferPrep(desc) {
  const m = String(desc ?? '').toLowerCase().match(/\b(fried|pan-fried|baked|grilled|roasted|boiled|steamed|braised|broiled|stewed|microwaved|scrambled|toasted)\b/);
  return m ? m[1] : null;
}
