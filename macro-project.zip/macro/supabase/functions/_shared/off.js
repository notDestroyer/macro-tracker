// Open Food Facts adapter. Requires a custom User-Agent (AppName/Version (email)). Limits per their docs: 15 reads/min and 10 searches/min per IP.
// STATUS: written from documented shapes; not yet verified against live responses (run scripts/smoke.mjs).
import { mapOffNutriments, toMap, plausibilityIssues } from './nutrients.js';
import { normalizeGtin } from './barcode.js';

export const OFF_BASE = 'https://world.openfoodfacts.org';
const FIELDS = 'code,product_name,product_name_en,generic_name,brands,quantity,serving_size,serving_quantity,serving_quantity_unit,nutriments,allergens_tags,traces_tags,ingredients_text,categories_tags,image_front_small_url,last_modified_t';

async function call(url, userAgent, fetchImpl, timeoutMs = 8000) {
  if (!userAgent) throw new Error('OFF requires a custom User-Agent');
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const res = await fetchImpl(url, { headers: { 'User-Agent': userAgent, Accept: 'application/json' }, signal: ctl.signal });
    if (res.status === 404) return { notFound: true };
    if (res.status === 429 || res.status === 503) throw Object.assign(new Error('OFF rate limited or unavailable'), { code: 'rate_limited' });
    if (!res.ok) throw Object.assign(new Error(`OFF HTTP ${res.status}`), { code: 'http_error', status: res.status });
    return await res.json();
  } finally { clearTimeout(t); }
}
export async function offGetProduct({ code, userAgent, fetchImpl = fetch }) {
  const j = await call(`${OFF_BASE}/api/v3/product/${encodeURIComponent(code)}?fields=${FIELDS}`, userAgent, fetchImpl);
  if (j.notFound) return null;
  const found = (j.status === 'success' || j.status === 1) && j.product; // v3 uses 'success', v2 uses 1
  return found ? { code: j.code || code, ...j.product } : null;
}
export async function offSearch({ query, userAgent, pageSize = 8, fetchImpl = fetch }) {
  const q = new URLSearchParams({ search_terms: query, search_simple: '1', action: 'process', json: '1', page_size: String(pageSize), fields: FIELDS });
  const j = await call(`${OFF_BASE}/cgi/search.pl?${q}`, userAgent, fetchImpl);
  return j.notFound ? [] : j.products || [];
}

const tag = (t) => String(t).replace(/^[a-z]{2}:/, '');
export function normalizeOffProduct(p, { now = new Date().toISOString() } = {}) {
  const name = (p.product_name || p.product_name_en || p.generic_name || '').trim();
  const { nutrients, warnings } = mapOffNutriments(p.nutriments || {});
  const map = toMap(nutrients);
  const issues = plausibilityIssues(map);
  const unitHint = String(p.serving_quantity_unit || p.serving_size || p.quantity || '').toLowerCase();
  const ml = /\b(ml|cl|l)\b/.test(unitHint) && !/\bg\b/.test(unitHint);
  const sq = Number(p.serving_quantity);
  const servings = sq > 0 ? [{ label: p.serving_size || `${sq} ${ml ? 'ml' : 'g'}`, amount: 1, unit: 'serving', modifier: '', grams: ml ? null : sq, ml: ml ? sq : null, state: null, is_default: true, confidence: 'moderate', source: 'off_serving' }] : [];
  const gtin = normalizeGtin(p.code);
  const complete = ['energy_kcal', 'protein', 'fat_total', 'carb_total'].every((k) => map[k] != null);
  return {
    source_key: 'off', source_ref: String(p.code), name, brand: String(p.brands || '').split(',')[0].trim() || null, manufacturer: null,
    category: (p.categories_tags || []).slice(-1).map(tag)[0] || null, kind: 'branded', state: null, prep: null, basis: ml ? 'ml' : 'g',
    verification: issues.length ? 'flagged' : 'imported', confidence: issues.length || !complete ? 'low' : 'moderate', fetched_at: now,
    nutrients, servings, barcodes: gtin.ok ? [{ original: String(p.code), gtin14: gtin.gtin14 }] : [], aliases: [],
    attrs: { // absent allergen data means UNKNOWN, not allergen-free
      allergens_declared: (p.allergens_tags || []).map(tag), traces_declared: (p.traces_tags || []).map(tag), ingredients: p.ingredients_text || null,
      image: p.image_front_small_url || null, off_last_modified: p.last_modified_t || null, detail_loaded: true, issues, mapping_warnings: warnings },
  };
}
