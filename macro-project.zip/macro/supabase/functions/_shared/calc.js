// One entry point for "this much of this food": amount in basis, scaled nutrients, weakest-link confidence.
import { toBasisAmount } from './units.js';
import { scaleNutrients } from './nutrients.js';
import { combineConfidence } from './confidence.js';

/**
 * food: { basis, state, servings, nutrients:{key:per100}, confidence }
 * qty: { amount, unit }; opts: { state, modifier, identification: 'exact'|'close'|'ambiguous' }
 */
export function calcItem(food, qty, opts = {}) {
  const r = toBasisAmount(food, qty, opts);
  if (!r.ok) return r;
  return {
    ok: true, amount: r.amount, basis: r.basis, method: r.method, assumptions: r.assumptions,
    nutrients: scaleNutrients(food.nutrients, r.amount),
    confidence: combineConfidence({ source: food.confidence || 'low', identification: opts.identification || 'exact', portion: r.confidence }),
  };
}
