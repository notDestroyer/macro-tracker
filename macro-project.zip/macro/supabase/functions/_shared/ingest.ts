// Normalizes external records and writes them through the ingest_food RPC. Used by all three functions.
import { quota } from './http.ts';
import { usdaSearch, usdaGetFood, normalizeUsdaFood } from './usda.js';
import { offSearch, offGetProduct, normalizeOffProduct } from './off.js';
import { rankCandidates } from './ranking.js';
import { toMap } from './nutrients.js';
import { SOURCE_TIER } from './reference.js';

const hasEnergy = (f: any) => f.nutrients.some((n: any) => n.key === 'energy_kcal');
export const rankable = (f: any) => ({ ...f, tier: SOURCE_TIER[f.source_key], nutrients: toMap(f.nutrients) });

export async function ingest(admin: any, food: any) {
  const { data, error } = await admin.rpc('ingest_food', { p: food });
  if (error) throw error;
  return data as string;
}

// Each helper reports a short status string for the response meta; a failure in one source never blocks the other.
export async function usdaSearchAndIngest(admin: any, q: string, limit = 8): Promise<string> {
  const apiKey = Deno.env.get('USDA_API_KEY');
  if (!apiKey) return 'not_configured';
  if (!(await quota(admin, 'g:usda', 900, 3600))) return 'rate_limited';
  try {
    const res = await usdaSearch({ apiKey, query: q, pageSize: 15 });
    const foods = (res.foods ?? []).map((j: any) => normalizeUsdaFood(j)).filter(hasEnergy);
    const top = rankCandidates(q, foods.map(rankable)).slice(0, limit);
    let n = 0;
    for (const f of top) { await ingest(admin, f); n++; }
    return `ok:${n}`;
  } catch (e) { return `error:${(e as any).code ?? 'unknown'}`; }
}

export async function offSearchAndIngest(admin: any, q: string, limit = 6): Promise<string> {
  const userAgent = Deno.env.get('OFF_USER_AGENT');
  if (!userAgent) return 'not_configured';
  if (!(await quota(admin, 'g:off:search', 8, 60))) return 'rate_limited';
  try {
    const products = await offSearch({ query: q, userAgent, pageSize: 12 });
    const foods = products.map((p: any) => normalizeOffProduct(p)).filter((f: any) => f.name && hasEnergy(f));
    const top = rankCandidates(q, foods.map(rankable)).slice(0, limit);
    let n = 0;
    for (const f of top) { await ingest(admin, f); n++; }
    return `ok:${n}`;
  } catch (e) { return `error:${(e as any).code ?? 'unknown'}`; }
}

export async function usdaFetchOne(admin: any, fdcId: string): Promise<string> {
  const apiKey = Deno.env.get('USDA_API_KEY');
  if (!apiKey) return 'not_configured';
  if (!(await quota(admin, 'g:usda', 900, 3600))) return 'rate_limited';
  try { await ingest(admin, normalizeUsdaFood(await usdaGetFood({ apiKey, fdcId }))); return 'ok'; }
  catch (e) { return `error:${(e as any).code ?? 'unknown'}`; }
}

export async function usdaBrandedByGtin(admin: any, gtin14: string): Promise<string> {
  const apiKey = Deno.env.get('USDA_API_KEY');
  if (!apiKey) return 'not_configured';
  if (!(await quota(admin, 'g:usda', 900, 3600))) return 'rate_limited';
  try {
    const res = await usdaSearch({ apiKey, query: gtin14.replace(/^0+/, ''), pageSize: 5, dataTypes: ['Branded'] });
    let n = 0;
    for (const j of res.foods ?? []) {
      const f = normalizeUsdaFood(j);
      // Only keep records whose own barcode normalizes to the scanned code.
      if (hasEnergy(f) && f.barcodes.some((b: any) => b.gtin14 === gtin14)) { await ingest(admin, f); n++; }
    }
    return `ok:${n}`;
  } catch (e) { return `error:${(e as any).code ?? 'unknown'}`; }
}

export async function offFetchByGtin(admin: any, gtin14: string): Promise<string> {
  const userAgent = Deno.env.get('OFF_USER_AGENT');
  if (!userAgent) return 'not_configured';
  if (!(await quota(admin, 'g:off:read', 12, 60))) return 'rate_limited';
  try {
    const code = gtin14.startsWith('0') ? gtin14.slice(1) : gtin14; // OFF stores UPC-A as 13 digits with a leading zero
    const p = await offGetProduct({ code, userAgent });
    if (!p) return 'not_found';
    const f = normalizeOffProduct(p);
    if (!f.name || !hasEnergy(f)) return 'incomplete';
    await ingest(admin, f);
    return 'ok:1';
  } catch (e) { return `error:${(e as any).code ?? 'unknown'}`; }
}
