// Unit and serving conversion. Pure functions, no I/O. Runs in Deno, Node and browsers.
// Foods are measured in their basis unit: grams (basis 'g') or milliliters (basis 'ml', typical for beverages).
import { minLevel } from './confidence.js';

export const G_PER_OZ = 28.349523125;
export const G_PER_LB = 453.59237;
export const ML_PER = { ml: 1, l: 1000, cup: 236.5882365, tbsp: 14.78676478125, tsp: 4.92892159375, floz: 29.5735295625 };
export const MASS_G = { mg: 0.001, g: 1, kg: 1000, oz: G_PER_OZ, lb: G_PER_LB };

const ALIAS = {
  gram: 'g', grams: 'g', gr: 'g', kilogram: 'kg', kilograms: 'kg', milligram: 'mg', milligrams: 'mg',
  ounce: 'oz', ounces: 'oz', pound: 'lb', pounds: 'lb', lbs: 'lb',
  milliliter: 'ml', milliliters: 'ml', millilitre: 'ml', millilitres: 'ml', liter: 'l', liters: 'l', litre: 'l', litres: 'l',
  cups: 'cup', c: 'cup', tablespoon: 'tbsp', tablespoons: 'tbsp', tbs: 'tbsp', tbsps: 'tbsp', teaspoon: 'tsp', teaspoons: 'tsp', tsps: 'tsp',
  'fl oz': 'floz', 'fl. oz': 'floz', 'fluid ounce': 'floz', 'fluid ounces': 'floz',
  piece: 'each', pieces: 'each', item: 'each', items: 'each', slices: 'slice', scoops: 'scoop', servings: 'serving',
  handfuls: 'handful', bowls: 'bowl', plates: 'plate',
};
export function canonUnit(u) {
  const k = String(u ?? '').trim().toLowerCase().replace(/\.$/, '');
  return ALIAS[k] ?? k;
}
export const unitKind = (u) =>
  u in MASS_G ? 'mass' : u in ML_PER ? 'volume' : ['handful', 'bowl', 'plate'].includes(u) ? 'ambiguous' : 'count';

const ok = (amount, basis, method, confidence, assumptions = []) => ({ ok: true, amount, basis, method, confidence, assumptions });
const fail = (reason, extra = {}) => ({ ok: false, reason, ...extra });
const inBasis = (s, basis) => (basis === 'ml' ? (s.ml > 0 ? s.ml : null) : s.grams > 0 ? s.grams : null);
const perUnit = (s, basis) => inBasis(s, basis) / (s.amount || 1);

function pick(list, modifier, assumptions) {
  if (modifier) {
    const m = list.filter((s) => (s.modifier || '').toLowerCase().includes(String(modifier).toLowerCase()));
    if (m.length) list = m;
    else assumptions.push(`No “${modifier}” portion on record; used another portion.`);
  }
  const s = list.find((x) => x.is_default) || list[0];
  if (list.length > 1 && !modifier) assumptions.push(`Several portions on record; used “${s.label || s.modifier || s.unit}”.`);
  return s;
}

// Density (g per ml) only from this food's own portions. Never from water.
function density(servings, modifier) {
  let c = servings.filter((s) => s.grams > 0 && (s.ml > 0 || unitKind(s.unit) === 'volume'));
  if (!c.length) return null;
  if (modifier) { const m = c.filter((s) => (s.modifier || '').toLowerCase().includes(String(modifier).toLowerCase())); if (m.length) c = m; }
  else { const plain = c.filter((s) => !s.modifier); if (plain.length) c = plain; }
  const s = c[0];
  const ml = s.ml > 0 ? s.ml : (s.amount || 1) * ML_PER[s.unit];
  return { gPerMl: s.grams / ml, confidence: s.confidence || 'moderate' };
}

/**
 * Convert a quantity to the food's basis unit (grams or ml).
 * food: { basis, state, liquid, servings: [{amount, unit, modifier, label, grams, ml, state, is_default, confidence}] }
 * qty: { amount, unit }; opts: { state: 'raw'|'cooked'|..., modifier: 'chopped' }
 * Returns { ok:true, amount, basis, method, confidence, assumptions } or { ok:false, reason, ... }.
 */
export function toBasisAmount(food, qty, opts = {}) {
  const n = Number(qty?.amount);
  if (!(n > 0) || !Number.isFinite(n)) return fail('bad_amount');
  const basis = food.basis || 'g';
  const state = opts.state || null;
  if (state && food.state && food.state !== state) return fail('state_mismatch', { have: food.state, want: state });
  const servings = (food.servings || []).filter((s) => !state || !s.state || s.state === state);
  const assumptions = [];
  let u = canonUnit(qty.unit);
  if (u === 'oz' && (basis === 'ml' || food.liquid)) { u = 'floz'; assumptions.push('Read “oz” as fluid ounces because this is a liquid.'); }
  const kind = unitKind(u);

  if (kind === 'mass') {
    const g = n * MASS_G[u];
    if (basis === 'g') return ok(g, 'g', 'mass_exact', 'high', assumptions);
    const d = density(servings, opts.modifier);
    if (!d) return fail('needs_density', { unit: u });
    return ok(g / d.gPerMl, 'ml', 'mass_via_density', minLevel(d.confidence, 'moderate'), assumptions);
  }
  if (kind === 'volume') {
    const ml = n * ML_PER[u];
    if (basis === 'ml') return ok(ml, 'ml', 'volume_exact', 'high', assumptions);
    const direct = servings.filter((s) => s.unit === u && inBasis(s, 'g'));
    if (direct.length) { const s = pick(direct, opts.modifier, assumptions); return ok(n * perUnit(s, 'g'), 'g', 'serving_match', s.confidence || 'moderate', assumptions); }
    const d = density(servings, opts.modifier);
    if (d) return ok(ml * d.gPerMl, 'g', 'serving_density', d.confidence, assumptions);
    if (food.densityGPerMl > 0) return ok(ml * food.densityGPerMl, 'g', 'reference_density', 'low', [...assumptions, 'Density is a generic reference, not a measured portion.']);
    return fail('needs_density', { unit: u });
  }
  // count-like units (each, slice, scoop, serving) and ambiguous ones (handful, bowl, plate)
  const usable = servings.filter((s) => inBasis(s, basis));
  const matches = u === 'serving' ? usable : usable.filter((s) => s.unit === u);
  if (matches.length) {
    const s = pick(matches, opts.modifier, assumptions);
    return ok(n * perUnit(s, basis), basis, 'serving_match', kind === 'ambiguous' ? 'low' : s.confidence || 'moderate', assumptions);
  }
  return fail(kind === 'ambiguous' ? 'ambiguous_quantity' : 'no_serving_for_unit', {
    unit: u, suggestions: usable.map((s) => ({ label: s.label || s.unit, grams: s.grams ?? null, ml: s.ml ?? null })),
  });
}
