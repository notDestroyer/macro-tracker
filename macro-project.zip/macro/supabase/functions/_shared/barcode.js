// GTIN handling. All barcodes are stored as 14 digits (left-padded), so UPC-A and EAN-13 forms of one product match.
export function gs1CheckDigit(body) {
  let s = 0;
  for (let i = 0; i < body.length; i++) s += Number(body[body.length - 1 - i]) * (i % 2 === 0 ? 3 : 1);
  return (10 - (s % 10)) % 10;
}
export const validGtin = (c) => /^(\d{8}|\d{12,14})$/.test(c) && gs1CheckDigit(c.slice(0, -1)) === Number(c.slice(-1));

// UPC-E (8 digits: number system 0/1, six digits, check digit) -> UPC-A (12 digits).
export function upcEtoUpcA(e) {
  if (!/^[01]\d{7}$/.test(e)) return null;
  const ns = e[0], d = e.slice(1, 7), chk = e[7], last = d[5];
  let body;
  if ('012'.includes(last)) body = ns + d[0] + d[1] + last + '0000' + d[2] + d[3] + d[4];
  else if (last === '3') body = ns + d[0] + d[1] + d[2] + '00000' + d[3] + d[4];
  else if (last === '4') body = ns + d[0] + d[1] + d[2] + d[3] + '00000' + d[4];
  else body = ns + d.slice(0, 5) + '0000' + last;
  const a = body + chk;
  return validGtin(a) ? a : null;
}

/** Returns { ok, gtin14, candidates:[{gtin14,type}], original } or { ok:false, reason }. */
export function normalizeGtin(input) {
  const original = String(input ?? '').trim();
  const digits = original.replace(/[\s-]/g, '');
  if (!/^\d+$/.test(digits)) return { ok: false, reason: 'not_numeric' };
  const cands = [];
  const add = (code, type) => { if (validGtin(code)) cands.push({ gtin14: code.padStart(14, '0'), type }); };
  if (digits.length === 8) {
    const a = upcEtoUpcA(digits);
    if (a) add(a, 'UPC-E');
    add(digits, 'EAN-8');
  } else if (digits.length === 12) add(digits, 'UPC-A');
  else if (digits.length === 13) add(digits, 'EAN-13');
  else if (digits.length === 14) add(digits, 'GTIN-14');
  else return { ok: false, reason: 'bad_length' };
  if (!cands.length) return { ok: false, reason: 'bad_check_digit' };
  return { ok: true, gtin14: cands[0].gtin14, candidates: cands, original };
}
