// USDA FoodData Central adapter: HTTP client (fetch injected for tests) and normalizer.
// STATUS: written from the documented response shapes; not yet verified against live responses (run scripts/smoke.mjs).
import { mapUsdaNutrients, toMap, plausibilityIssues } from './nutrients.js';
import { inferState, inferPrep } from './text.js';
import { canonUnit, unitKind } from './units.js';
import { normalizeGtin } from './barcode.js';

export const USDA_BASE = 'https://api.nal.usda.gov/fdc/v1';
const TYPE = {
  Foundation: ['usda_foundation', 'generic', 'verified', 'high'],
  'SR Legacy': ['usda_sr_legacy', 'generic', 'verified', 'high'],
  'Survey (FNDDS)': ['usda_fndds', 'generic', 'verified', 'moderate'],
  Branded: ['usda_branded', 'branded', 'imported', 'moderate'],
};

async function call(url, init, fetchImpl, timeoutMs = 8000) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const res = await fetchImpl(url, { ...init, signal: ctl.signal });
    if (res.status === 429) throw Object.assign(new Error('USDA rate limited'), { code: 'rate_limited' });
    if (!res.ok) throw Object.assign(new Error(`USDA HTTP ${res.status}`), { code: 'http_error', status: res.status });
    return await res.json();
  } finally { clearTimeout(t); }
}
export const usdaSearch = ({ apiKey, query, pageSize = 10, dataTypes = Object.keys(TYPE), fetchImpl = fetch }) =>
  call(`${USDA_BASE}/foods/search`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Api-Key': apiKey },
    body: JSON.stringify({ query, pageSize, dataType: dataTypes, requireAllWords: true }) }, fetchImpl);
export const usdaGetFood = ({ apiKey, fdcId, fetchImpl = fetch }) =>
  call(`${USDA_BASE}/food/${encodeURIComponent(fdcId)}`, { headers: { 'X-Api-Key': apiKey } }, fetchImpl);

// Portion unit: use the explicit measure unit if it is one we know, else the leading unit word in the description, else 'each'.
const UNIT_WORD = /^(?:[\d.\/\s]*)(cups?|tbsp|tablespoons?|tsp|teaspoons?|fl\.? oz|fluid ounces?|slices?|scoops?|ml|oz|g)\b/i;
function portionToServing(p, foodState) {
  const grams = Number(p.gramWeight);
  if (!(grams > 0)) return null;
  const amount = Number(p.amount) > 0 ? Number(p.amount) : 1;
  const mu = canonUnit(p.measureUnit?.name || '');
  const text = String(p.portionDescription || p.modifier || '').trim();
  let unit = unitKind(mu) === 'volume' || ['slice', 'scoop', 'each'].includes(mu) ? mu : null;
  let modifier = text;
  if (!unit) { const m = text.match(UNIT_WORD); if (m) { unit = canonUnit(m[1].toLowerCase()); modifier = text.slice(m[0].length).replace(/^[\s,()]+/, ''); } }
  if (!unit || unitKind(unit) === 'mass') { unit = 'each'; modifier = text || p.measureUnit?.name || ''; }
  if (/^undetermined$/i.test(modifier)) modifier = '';
  return { label: text || `${amount} ${p.measureUnit?.name || 'portion'}`, amount, unit, modifier, grams, ml: null, state: foodState, is_default: false, confidence: 'moderate', source: 'usda_portion' };
}

/** Normalize a USDA search hit or full food record into the internal shape used by ingest_food. */
export function normalizeUsdaFood(j, { now = new Date().toISOString() } = {}) {
  const dt = j.dataType || 'Branded';
  const [source_key, kind, verification, confidence0] = TYPE[dt] || TYPE.Branded;
  const { nutrients, warnings, ignored } = mapUsdaNutrients(j.foodNutrients || []);
  const map = toMap(nutrients);
  const issues = plausibilityIssues(map);
  const ml = /^(ml|mlt)$/i.test(j.servingSizeUnit || '');
  const desc = j.description || '';
  const state = inferState(desc);
  let servings = (j.foodPortions || []).map((p) => portionToServing(p, state)).filter(Boolean);
  if (kind === 'branded' && Number(j.servingSize) > 0) {
    const s = Number(j.servingSize);
    servings.unshift({ label: j.householdServingFullText || `${s} ${ml ? 'ml' : 'g'}`, amount: 1, unit: 'serving', modifier: '', grams: ml ? null : s, ml: ml ? s : null, state: null, is_default: true, confidence: 'high', source: 'label_serving' });
  }
  const lc = j.labelNutrients?.calories?.value, sv = Number(j.servingSize);
  if (kind === 'branded' && lc != null && sv > 0 && map.energy_kcal != null) {
    const fromPer100 = (map.energy_kcal * sv) / 100;
    if (Math.abs(fromPer100 - lc) > Math.max(15, 0.15 * lc)) issues.push(`label calories per serving (${lc}) disagree with per-100 data (${Math.round(fromPer100)})`);
  }
  const complete = ['energy_kcal', 'protein', 'fat_total', 'carb_total'].every((k) => map[k] != null);
  return {
    source_key, source_ref: String(j.fdcId), name: desc, brand: j.brandName || j.brandOwner || null, manufacturer: j.brandOwner || null,
    category: j.foodCategory?.description || j.foodCategory || j.brandedFoodCategory || null, kind, state, prep: inferPrep(desc),
    basis: ml ? 'ml' : 'g', verification: issues.length ? 'flagged' : verification, confidence: issues.length || !complete ? 'low' : confidence0,
    fetched_at: now, nutrients, servings, barcodes: (() => { const g = j.gtinUpc ? normalizeGtin(j.gtinUpc) : null; return g?.ok ? [{ original: String(j.gtinUpc), gtin14: g.gtin14 }] : []; })(), aliases: [],
    attrs: { data_type: dt, ingredients: j.ingredients || null, usda_published: j.publicationDate || null, detail_loaded: Array.isArray(j.foodPortions) || kind === 'branded' && !!j.labelNutrients, issues, mapping_warnings: warnings, unmapped_count: ignored.length },
  };
}
