// Phase 1 -> Phase 2 data migration. Input is the JSON from the Phase 1 "Export data" button.
// Fixes: (1) unknown nutrients stay unknown; (2) entries reference permanent seed ids (legacy_ref 'seed:N'), resolved to foods.id at import.
export function migratePhase1(state, legacySeed) {
  const report = { entries: 0, linked: 0, quickAdd: 0, mismatches: [], warnings: [] };
  const entries = [];
  for (const [day, list] of Object.entries(state.log || {})) {
    for (const e of list || []) {
      report.entries++;
      const linked = e.fid != null;
      const n = { energy_kcal: Number(e.k) };
      let prov = 'user', conf = null, ref = null;
      if (linked) {
        const seed = legacySeed[e.fid];
        ref = `seed:${e.fid}`; prov = 'legacy_seed'; conf = 'low'; report.linked++;
        if (!seed) report.mismatches.push({ id: e.id, day, name: e.n, problem: `no seed food at index ${e.fid}` });
        else {
          if (seed.name !== e.n) report.mismatches.push({ id: e.id, day, name: e.n, problem: `index ${e.fid} is “${seed.name}”` });
          const allowed = (0.5 * seed.kcal) / 100 + 0.2; // Phase 1 rounded grams to whole numbers
          if (e.g > 0 && Math.abs(seed.kcal * e.g / 100 - e.k) > Math.max(allowed, 0.01 * e.k)) report.mismatches.push({ id: e.id, day, name: e.n, problem: `calories ${e.k} do not match ${seed.name} × ${e.g} g` });
        }
        Object.assign(n, { protein: e.p, carb_total: e.c, fat_total: e.f, fiber: e.fi, sodium: e.na });
      } else {
        report.quickAdd++;
        const macrosBlank = !e.p && !e.c && !e.f && e.k > 0; // Phase 1 saved blank macros as 0: treat as unknown
        if (!macrosBlank) Object.assign(n, { protein: e.p, carb_total: e.c, fat_total: e.f });
        // fiber and sodium were never asked for in quick-add, so they were not real zeros: left out = unknown
      }
      for (const k of Object.keys(n)) if (!Number.isFinite(n[k])) delete n[k];
      entries.push({ legacy_id: String(e.id), logged_on: day, meal: e.meal, name: e.n, legacy_ref: ref, quantity: e.q === '' || e.q == null ? null : Number(e.q), unit_label: e.u || null, grams: e.g > 0 ? e.g : null, nutrients: n, provenance: prov, confidence: conf });
    }
  }
  const water = Object.entries(state.water || {}).filter(([, ml]) => ml > 0).map(([day, ml]) => ({ day, ml: Math.round(ml) }));
  return { profile: state.profile || null, targets: state.targets || null, entries, water, report };
}
