// Nutrient mapping and arithmetic. Rule: a missing nutrient is UNKNOWN (absent), never zero.
import { NUTRIENTS } from './reference.js';

export const KEYS = new Set(NUTRIENTS.map((n) => n.key));
const UNIT = Object.fromEntries(NUTRIENTS.map((n) => [n.key, n.unit]));

// USDA FoodData Central nutrient id -> [canonical key, expected unit, expected name pattern].
// An id is accepted only if its unit AND name also match, so a wrong id is reported instead of silently mis-mapped.
const USDA = {
  1008: ['energy_kcal', 'kcal', /^energy/i], 2047: ['energy_kcal', 'kcal', /^energy/i], 2048: ['energy_kcal', 'kcal', /^energy/i],
  1003: ['protein', 'g', /^protein/i], 1004: ['fat_total', 'g', /total lipid|total fat/i],
  1005: ['carb_total', 'g', /^carbohydrate, by difference/i], 1079: ['fiber', 'g', /fiber, total dietary/i],
  2000: ['sugars_total', 'g', /^sugars, total/i], 1235: ['sugars_added', 'g', /sugars, added/i],
  1258: ['fat_sat', 'g', /saturated/i], 1292: ['fat_mono', 'g', /monounsaturated/i], 1293: ['fat_poly', 'g', /polyunsaturated/i],
  1257: ['fat_trans', 'g', /trans/i], 1253: ['cholesterol', 'mg', /cholesterol/i], 1093: ['sodium', 'mg', /^sodium/i],
  1092: ['potassium', 'mg', /^potassium/i], 1087: ['calcium', 'mg', /^calcium/i], 1089: ['iron', 'mg', /^iron/i],
  1090: ['magnesium', 'mg', /^magnesium/i], 1095: ['zinc', 'mg', /^zinc/i], 1091: ['phosphorus', 'mg', /^phosphorus/i],
  1106: ['vit_a_rae', 'ug', /vitamin a, rae/i], 1162: ['vit_c', 'mg', /vitamin c/i], 1114: ['vit_d', 'ug', /^vitamin d/i],
  1109: ['vit_e', 'mg', /vitamin e/i], 1185: ['vit_k', 'ug', /vitamin k/i], 1165: ['thiamin', 'mg', /thiamin/i],
  1166: ['riboflavin', 'mg', /riboflavin/i], 1167: ['niacin', 'mg', /niacin/i], 1175: ['vit_b6', 'mg', /vitamin b-6/i],
  1178: ['vit_b12', 'ug', /vitamin b-12/i], 1177: ['folate_total', 'ug', /folate, total/i], 1190: ['folate_dfe', 'ug', /folate, dfe/i],
  1180: ['choline', 'mg', /choline, total/i], 1051: ['water', 'g', /^water/i], 1057: ['caffeine', 'mg', /^caffeine/i],
  1018: ['alcohol', 'g', /alcohol/i],
};
const ENERGY_PREF = [1008, 2047, 2048];
const normUnit = (u) => { const x = String(u ?? '').toLowerCase().replace('µ', 'u').replace('μ', 'u'); return x === 'mcg' ? 'ug' : x; };

// Accepts both USDA shapes: detail {nutrient:{id,name,unitName}, amount} and search {nutrientId, nutrientName, unitName, value}.
export function mapUsdaNutrients(list = []) {
  const entries = list.map((e) => ({
    id: Number(e.nutrient?.id ?? e.nutrientId), name: e.nutrient?.name ?? e.nutrientName ?? '',
    unit: normUnit(e.nutrient?.unitName ?? e.unitName), amount: e.amount ?? e.value,
  }));
  const out = new Map(), warnings = [], ignored = [];
  for (const e of entries) {
    const m = USDA[e.id];
    if (!m) { ignored.push({ id: e.id, name: e.name }); continue; }
    const [key, unit, re] = m;
    if (e.amount == null || e.amount === '' || !Number.isFinite(Number(e.amount))) continue;
    if (e.unit !== unit || !re.test(e.name)) { warnings.push({ id: e.id, name: e.name, unit: e.unit, expected: `${key} (${unit})`, reason: 'id matched but unit or name did not' }); continue; }
    const v = Number(e.amount);
    if (v < 0) { warnings.push({ id: e.id, name: e.name, reason: 'negative amount' }); continue; }
    const prev = out.get(key);
    if (key === 'energy_kcal' && prev && ENERGY_PREF.indexOf(prev.src) <= ENERGY_PREF.indexOf(e.id)) continue;
    if (prev && key !== 'energy_kcal') continue; // first reported value wins; duplicates are not averaged
    out.set(key, { key, per100g: v, reported_amount: v, reported_unit: e.unit, reported_basis: 'per_100', derivation: 'reported', src: e.id });
  }
  return { nutrients: [...out.values()].map(({ src, ...r }) => r), warnings, ignored };
}

// Open Food Facts reports *_100g in grams (energy_100g in kJ). Salt is converted to sodium only when sodium is absent.
const OFF_G = { protein: 'proteins', fat_total: 'fat', carb_total: 'carbohydrates', fiber: 'fiber', sugars_total: 'sugars', sugars_added: 'added-sugars', fat_sat: 'saturated-fat', fat_trans: 'trans-fat' };
const OFF_MG = { cholesterol: 'cholesterol', sodium: 'sodium', potassium: 'potassium', calcium: 'calcium', iron: 'iron', vit_c: 'vitamin-c' };
const num = (v) => (v === '' || v == null || !Number.isFinite(Number(v)) ? null : Number(v));
export function mapOffNutriments(nu = {}) {
  const out = [], warnings = [];
  const push = (key, v, reported_unit, reported_amount, derivation = 'reported') => {
    if (v == null) return;
    if (v < 0) { warnings.push({ key, reason: 'negative amount' }); return; }
    out.push({ key, per100g: v, reported_amount, reported_unit, reported_basis: 'per_100', derivation });
  };
  const kcal = num(nu['energy-kcal_100g']), kj = num(nu['energy_100g']);
  if (kcal != null) push('energy_kcal', kcal, 'kcal', kcal);
  else if (kj != null) push('energy_kcal', kj / 4.184, 'kj', kj, 'calculated');
  for (const [k, off] of Object.entries(OFF_G)) { const v = num(nu[`${off}_100g`]); push(k, v, 'g', v); }
  for (const [k, off] of Object.entries(OFF_MG)) { const v = num(nu[`${off}_100g`]); if (v != null) push(k, v * 1000, 'g', v); }
  if (!out.some((r) => r.key === 'sodium')) {
    const salt = num(nu['salt_100g']);
    if (salt != null) push('sodium', salt * 400, 'g salt', salt, 'calculated'); // sodium = salt / 2.5
  }
  return { nutrients: out, warnings };
}

// Plausibility gate for per-100 values. Failing records are flagged low confidence, never silently fixed.
export function plausibilityIssues(map) {
  const v = (k) => (map[k] == null ? null : map[k]);
  const issues = [];
  for (const [k, x] of Object.entries(map)) {
    if (UNIT[k] === 'g' && x > 100.5) issues.push(`${k} exceeds 100 g per 100`);
    if (x < 0) issues.push(`${k} is negative`);
  }
  if (v('energy_kcal') > 900) issues.push('energy above 900 kcal per 100');
  const macro = (v('protein') ?? 0) + (v('carb_total') ?? 0) + (v('fat_total') ?? 0);
  if (macro > 105) issues.push('protein + carbs + fat exceed 105 g per 100');
  if (v('sugars_total') != null && v('carb_total') != null && v('sugars_total') > v('carb_total') + 0.5) issues.push('sugars exceed total carbohydrate');
  if (v('fat_sat') != null && v('fat_total') != null && v('fat_sat') > v('fat_total') + 0.5) issues.push('saturated fat exceeds total fat');
  return issues;
}

export const toMap = (rows) => Object.fromEntries(rows.map((r) => [r.key, r.per100g]));

/** Scale per-100 values to an amount in the food's basis unit. Unknown stays unknown. */
export function scaleNutrients(per100, amountInBasis) {
  const out = {};
  for (const [k, v] of Object.entries(per100 || {})) if (v != null) out[k] = (v * amountInBasis) / 100;
  return out;
}

/** Unknown-aware sum. partial[key] = number of items that lacked it, so the UI can say "at least X". */
export function sumNutrients(items) {
  const totals = {}, partial = {};
  for (const it of items) for (const [k, v] of Object.entries(it || {})) if (v != null) totals[k] = (totals[k] ?? 0) + v;
  for (const k of Object.keys(totals)) { const miss = items.filter((it) => it?.[k] == null).length; if (miss) partial[k] = miss; }
  return { totals, partial };
}
