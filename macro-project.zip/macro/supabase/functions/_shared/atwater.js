// Atwater consistency check. Flags for investigation; never alters a reported value.
export function expectedKcal({ protein, carb_total, fat_total, fiber = null, alcohol = 0, sugar_alcohol = 0 }) {
  if (protein == null || carb_total == null || fat_total == null) return null;
  const f = fiber ?? 0, sa = sugar_alcohol ?? 0;
  const avail = Math.max(0, carb_total - f - sa);
  return 4 * protein + 4 * avail + 2 * f + 2.4 * sa + 9 * fat_total + 7 * (alcohol ?? 0);
}
// Flag only when the gap exceeds BOTH 10% and 20 kcal, so label rounding and low-calorie foods do not trigger noise.
export function checkAtwater(reportedKcal, macros) {
  const expected = expectedKcal(macros);
  if (reportedKcal == null || expected == null) return { status: 'insufficient', expected };
  const diff = reportedKcal - expected;
  const pct = Math.abs(diff) / Math.max(reportedKcal, expected, 1);
  return { status: Math.abs(diff) > 20 && pct > 0.1 ? 'flag' : 'ok', expected, diff, pct };
}
