// Confidence is a weakest-link rule, not an average. Agreement between databases never raises it.
const LEVEL = { low: 0, moderate: 1, high: 2 };
export const minLevel = (...l) => l.filter(Boolean).reduce((a, b) => (LEVEL[a] <= LEVEL[b] ? a : b), 'high');
export const tierToLevel = (tier) => (tier <= 2 ? 'high' : tier <= 4 ? 'moderate' : 'low');
export const IDENT = { exact: 'high', close: 'moderate', ambiguous: 'low' };
export function combineConfidence({ source, identification = 'exact', portion }) {
  return minLevel(source, IDENT[identification] ?? 'low', portion);
}
