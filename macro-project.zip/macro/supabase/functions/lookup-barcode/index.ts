// POST { code } -> { found, winner, alternates, discrepancies, meta }
// Local barcode index first. External lookup only if nothing local is fresh. Sources are never averaged: one winner, others kept as alternates.
import { cors, json, requireUser, quota } from '../_shared/http.ts';
import { usdaBrandedByGtin, offFetchByGtin } from '../_shared/ingest.ts';
import { normalizeGtin } from '../_shared/barcode.js';
import { compareFoods, pickWinner } from '../_shared/discrepancy.js';
import { SOURCES } from '../_shared/reference.js';

const ttlDays = (key: string) => SOURCES.find((s) => s.key === key)?.cache_ttl_days ?? null;
const fresh = (f: any) => { const t = ttlDays(f.source.key); return t == null || Date.now() - new Date(f.fetched_at).getTime() < t * 86400000; };

async function localFoods(ctx: any, gtins: string[]) {
  const { data: rows } = await ctx.user.from('barcodes').select('food_id').in('gtin14', gtins);
  const ids = [...new Set((rows ?? []).map((r: any) => r.food_id))];
  const foods = [];
  for (const id of ids) { const { data } = await ctx.user.rpc('get_food', { p_id: id }); if (data) foods.push(data); }
  return foods;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json(405, { error: 'method_not_allowed' });
  const ctx = await requireUser(req);
  if (!ctx) return json(401, { error: 'unauthorized' });
  let body: any;
  try { body = await req.json(); } catch { return json(400, { error: 'invalid_json' }); }
  const g = normalizeGtin(body?.code);
  if (!g.ok) return json(400, { error: 'invalid_barcode', reason: g.reason });
  if (!(await quota(ctx.admin, `u:${ctx.id}:barcode`, 200, 86400))) return json(429, { error: 'rate_limited' });

  const gtins = g.candidates.map((c: any) => c.gtin14);
  const meta: Record<string, string> = {};
  let foods = await localFoods(ctx, gtins);
  if (!foods.some(fresh)) {
    const [usda, off] = await Promise.all([usdaBrandedByGtin(ctx.admin, gtins[0]), offFetchByGtin(ctx.admin, gtins[0])]);
    Object.assign(meta, { usda, off });
    foods = await localFoods(ctx, gtins);
  }
  if (!foods.length) return json(200, { found: false, meta, fallbacks: ['name_search', 'manual_entry', 'label_photo'] });

  const rank = (f: any) => ({ ...f, tier: f.source.tier });
  const sorted = foods.map(rank).sort((a: any, b: any) => (pickWinner(a, b) === a ? -1 : 1));
  const [winner, ...alternates] = sorted;
  const discrepancies = alternates.map((a: any) => ({ alternate_id: a.id, ...compareFoods(winner, a) }));
  return json(200, { found: true, winner, alternates, discrepancies, meta });
});
