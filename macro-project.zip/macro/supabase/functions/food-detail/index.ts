// POST { food_id } -> { food, meta }. Loads full USDA portions on demand and refreshes stale records.
import { cors, json, requireUser } from '../_shared/http.ts';
import { usdaFetchOne, offFetchByGtin } from '../_shared/ingest.ts';
import { SOURCES } from '../_shared/reference.js';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const stale = (f: any) => { const t = SOURCES.find((s) => s.key === f.source.key)?.cache_ttl_days; return t != null && Date.now() - new Date(f.fetched_at).getTime() > t * 86400000; };

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json(405, { error: 'method_not_allowed' });
  const ctx = await requireUser(req);
  if (!ctx) return json(401, { error: 'unauthorized' });
  let body: any;
  try { body = await req.json(); } catch { return json(400, { error: 'invalid_json' }); }
  if (typeof body?.food_id !== 'string' || !UUID.test(body.food_id)) return json(400, { error: 'invalid_food_id' });

  let { data: food } = await ctx.user.rpc('get_food', { p_id: body.food_id });
  if (!food) return json(404, { error: 'not_found' });
  const meta: Record<string, string> = {};
  const needsDetail = food.source.key.startsWith('usda_') && !food.attrs?.detail_loaded;
  if (needsDetail || stale(food)) {
    if (food.source.key.startsWith('usda_')) meta.usda = await usdaFetchOne(ctx.admin, food.source.ref);
    else if (food.source.key === 'off' && food.barcodes?.[0]) meta.off = await offFetchByGtin(ctx.admin, food.barcodes[0]);
    const again = await ctx.user.rpc('get_food', { p_id: body.food_id });
    if (again.data) food = again.data;
  }
  return json(200, { food, meta });
});
