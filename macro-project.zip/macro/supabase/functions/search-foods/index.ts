// POST { q, limit?, offset?, online? } -> { results, meta }
// Local search always. External lookup (USDA + Open Food Facts) only when online=true, within per-user and global limits.
import { cors, json, clampInt, requireUser, quota } from '../_shared/http.ts';
import { usdaSearchAndIngest, offSearchAndIngest } from '../_shared/ingest.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json(405, { error: 'method_not_allowed' });
  const ctx = await requireUser(req);
  if (!ctx) return json(401, { error: 'unauthorized' });
  let body: any;
  try { body = await req.json(); } catch { return json(400, { error: 'invalid_json' }); }
  const q = typeof body?.q === 'string' ? body.q.trim() : '';
  if (q.length < 2 || q.length > 100) return json(400, { error: 'q must be 2 to 100 characters' });
  const limit = clampInt(body.limit, 1, 50, 20), offset = clampInt(body.offset, 0, 200, 0);

  if (!(await quota(ctx.admin, `u:${ctx.id}:search`, 600, 3600))) return json(429, { error: 'rate_limited' });
  const meta: Record<string, string> = {};
  if (body.online === true) {
    if (!(await quota(ctx.admin, `u:${ctx.id}:online`, 40, 86400))) meta.online = 'daily_limit_reached';
    else {
      const [usda, off] = await Promise.all([usdaSearchAndIngest(ctx.admin, q), offSearchAndIngest(ctx.admin, q)]);
      Object.assign(meta, { usda, off });
    }
  }
  const { data, error } = await ctx.user.rpc('search_foods', { q, lim: limit, offs: offset });
  if (error) return json(500, { error: 'search_failed' });
  return json(200, { results: data, meta });
});
