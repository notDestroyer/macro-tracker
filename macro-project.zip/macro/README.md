# Macro tracker

- `web/` static frontend (Phase 1 page, unchanged) served by Cloudflare Pages. `web/lib/` is a copy of the tested shared modules (`npm run sync`).
- `supabase/migrations/` schema, reference data, functions, Phase 1 starter foods (permanent ids).
- `supabase/functions/` Edge Functions `search-foods`, `lookup-barcode`, `food-detail`; shared logic in `_shared/` (plain JS, runs in Deno, Node and browsers).
- `tests/` `npm test` (Node 22, no dependencies). `scripts/smoke.mjs` live API check. `scripts/gen-sql.mjs` regenerates reference and legacy migrations.
- `SETUP.md` the steps only you can do.

Rules enforced by tests: unknown nutrients are never zero; raw and cooked are never crossed; volume converts only with food-specific data; one winning source, never an average; confidence is the weakest link.
