import test from 'node:test';
import assert from 'node:assert/strict';
import { readdirSync, readFileSync } from 'node:fs';

test('web/lib is an exact copy of the tested shared modules (run npm run sync if this fails)', () => {
  const src = new URL('../supabase/functions/_shared/', import.meta.url), dst = new URL('../web/lib/', import.meta.url);
  const files = readdirSync(src).filter((f) => f.endsWith('.js'));
  assert.ok(files.length >= 12);
  for (const f of files) assert.equal(readFileSync(new URL(f, dst), 'utf8'), readFileSync(new URL(f, src), 'utf8'), f);
});
