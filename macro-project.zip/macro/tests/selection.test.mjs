import test from 'node:test';
import assert from 'node:assert/strict';
import { pickWinner, compareFoods, completeness } from '../supabase/functions/_shared/discrepancy.js';
import { rankCandidates } from '../supabase/functions/_shared/ranking.js';
import { combineConfidence, tierToLevel, minLevel } from '../supabase/functions/_shared/confidence.js';

const mk = (o) => ({ basis: 'g', tier: 3, nutrients: { energy_kcal: 100, protein: 5, fat_total: 2, carb_total: 10 }, fetched_at: '2026-01-01', ...o });

test('source selection: tier first, then completeness, then recency; returns one record, never a blend', () => {
  const official = mk({ tier: 1, id: 'label' }), usda = mk({ tier: 3, id: 'usda' }), off = mk({ tier: 4, id: 'off' });
  assert.equal(pickWinner(usda, official), official); assert.equal(pickWinner(off, usda), usda);
  const sparse = mk({ id: 'sparse', nutrients: { energy_kcal: 100 } }), full = mk({ id: 'full', nutrients: { energy_kcal: 100, protein: 5, fat_total: 2, carb_total: 10, fiber: 1, sodium: 5 } });
  assert.equal(pickWinner(sparse, full), full);
  const old = mk({ id: 'old', fetched_at: '2025-01-01' }), fresh = mk({ id: 'fresh', fetched_at: '2026-06-01' });
  assert.equal(pickWinner(old, fresh), fresh);
  assert.ok(completeness({ energy_kcal: 1 }) < completeness(full.nutrients));
});
test('discrepancies: different states or preparations are not conflicts', () => {
  assert.equal(compareFoods(mk({ state: 'raw' }), mk({ state: 'cooked' })).comparable, false);
  assert.equal(compareFoods(mk({ prep: 'fried' }), mk({ prep: 'baked' })).comparable, false);
  assert.equal(compareFoods(mk({ basis: 'ml' }), mk({ basis: 'g' })).comparable, false);
});
test('discrepancies: flags real conflicts and tolerates rounding', () => {
  const same = compareFoods(mk(), mk({ nutrients: { energy_kcal: 104, protein: 5.5, fat_total: 2.4, carb_total: 10.8 } }));
  assert.deepEqual(same.conflicts, []);
  const conflict = compareFoods(mk({ nutrients: { energy_kcal: 165, protein: 31 } }), mk({ nutrients: { energy_kcal: 120, protein: 22.5 } }));
  assert.deepEqual(conflict.conflicts.map((c) => c.key), ['energy_kcal', 'protein']);
  assert.deepEqual(compareFoods(mk({ nutrients: { energy_kcal: 12 } }), mk({ nutrients: { energy_kcal: 18 } })).conflicts, []); // tiny absolute gap
});
test('ranking: generic query prefers the generic food; brand query prefers the brand', () => {
  const nutr = { energy_kcal: 165, protein: 31, fat_total: 3.6, carb_total: 0, fiber: 0, sodium: 74 };
  const generic = { name: 'Chicken, breast, roasted', kind: 'generic', tier: 2, nutrients: nutr };
  const nuggets = { name: 'Chicken breast nuggets', brand: 'Acme Foods', kind: 'branded', tier: 3, nutrients: nutr };
  assert.equal(rankCandidates('chicken breast', [nuggets, generic])[0], generic);
  const fage = { name: 'Total 0% Greek yogurt', brand: 'Fage', kind: 'branded', tier: 3, nutrients: nutr };
  const plain = { name: 'Yogurt, Greek, plain, nonfat', kind: 'generic', tier: 2, nutrients: nutr };
  assert.equal(rankCandidates('fage greek yogurt', [plain, fage])[0], fage);
  const partial = { name: 'Rice, white, cooked', kind: 'generic', tier: 2, nutrients: nutr };
  const unrelated = { name: 'Rice cake, caramel', kind: 'generic', tier: 2, nutrients: nutr };
  assert.equal(rankCandidates('white rice cooked', [unrelated, partial])[0], partial);
});
test('confidence is the weakest link, and agreement cannot raise it', () => {
  assert.equal(tierToLevel(1), 'high'); assert.equal(tierToLevel(3), 'moderate'); assert.equal(tierToLevel(6), 'low'); assert.equal(tierToLevel(7), 'low');
  assert.equal(minLevel('high', 'moderate', 'high'), 'moderate');
  assert.equal(combineConfidence({ source: 'high', identification: 'exact', portion: 'high' }), 'high');
  assert.equal(combineConfidence({ source: 'high', identification: 'ambiguous', portion: 'high' }), 'low');
  assert.equal(combineConfidence({ source: 'high', identification: 'exact', portion: 'low' }), 'low');
});
