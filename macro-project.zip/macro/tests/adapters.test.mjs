// NOTE: fixtures below are hand-built from the documented response shapes. They are NOT captured live responses.
// They prove the normalizers behave as designed; scripts/smoke.mjs proves the shapes match the real APIs.
import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeUsdaFood, usdaSearch, usdaGetFood } from '../supabase/functions/_shared/usda.js';
import { normalizeOffProduct, offGetProduct, offSearch } from '../supabase/functions/_shared/off.js';

const d = (id, name, unitName, amount) => ({ nutrient: { id, name, unitName }, amount });
const get = (f, k) => f.nutrients.find((n) => n.key === k);
const chicken = { fdcId: 171477, description: 'Chicken, breast, meat only, cooked, roasted', dataType: 'Foundation', foodCategory: { description: 'Poultry Products' },
  foodNutrients: [d(1008, 'Energy', 'kcal', 165), d(1003, 'Protein', 'g', 31), d(1004, 'Total lipid (fat)', 'g', 3.6), d(1005, 'Carbohydrate, by difference', 'g', 0), d(1093, 'Sodium, Na', 'mg', 74)],
  foodPortions: [{ amount: 1, gramWeight: 172, modifier: 'breast', measureUnit: { name: 'undetermined' } }, { amount: 1, gramWeight: 140, portionDescription: '1 cup, chopped or diced', measureUnit: { name: 'undetermined' } }] };

test('USDA Foundation record normalizes with provenance, state, prep and portions', () => {
  const f = normalizeUsdaFood(chicken, { now: '2026-11-03T00:00:00Z' });
  assert.equal(f.source_key, 'usda_foundation'); assert.equal(f.source_ref, '171477'); assert.equal(f.kind, 'generic');
  assert.equal(f.state, 'cooked'); assert.equal(f.prep, 'roasted'); assert.equal(f.verification, 'verified'); assert.equal(f.confidence, 'high');
  assert.equal(f.basis, 'g'); assert.equal(get(f, 'energy_kcal').per100g, 165); assert.equal(f.fetched_at, '2026-11-03T00:00:00Z');
  const cup = f.servings.find((s) => s.unit === 'cup'); assert.equal(cup.grams, 140); assert.equal(cup.modifier, 'chopped or diced'); assert.equal(cup.state, 'cooked');
  assert.equal(f.servings.find((s) => s.grams === 172).unit, 'each');
  assert.equal(f.attrs.detail_loaded, true); assert.deepEqual(f.attrs.issues, []);
});
test('USDA: missing nutrients are absent, not zero; incomplete records are low confidence', () => {
  const f = normalizeUsdaFood({ ...chicken, foodNutrients: [d(1008, 'Energy', 'kcal', 165)] });
  assert.equal(get(f, 'fiber'), undefined); assert.equal(get(f, 'protein'), undefined); assert.equal(f.confidence, 'low');
});
test('USDA: search hit (no portions) is marked as detail not loaded', () => {
  const hit = { fdcId: 1, description: 'Rice, white, long-grain, regular, cooked', dataType: 'SR Legacy', foodNutrients: [{ nutrientId: 1008, nutrientName: 'Energy', unitName: 'KCAL', value: 130 }] };
  const f = normalizeUsdaFood(hit); assert.equal(f.attrs.detail_loaded, false); assert.equal(f.state, 'cooked'); assert.equal(f.source_key, 'usda_sr_legacy');
});
test('USDA Branded: label serving, barcode normalization, label-vs-per100 cross-check', () => {
  const j = { fdcId: 2, description: 'GREEK YOGURT', dataType: 'Branded', brandOwner: 'Acme Dairy', brandName: 'Acme', gtinUpc: '036000291452', servingSize: 170, servingSizeUnit: 'g',
    householdServingFullText: '3/4 cup', labelNutrients: { calories: { value: 100 } }, ingredients: 'MILK',
    foodNutrients: [d(1008, 'Energy', 'kcal', 59), d(1003, 'Protein', 'g', 10), d(1004, 'Total lipid (fat)', 'g', 0.4), d(1005, 'Carbohydrate, by difference', 'g', 3.6)] };
  const f = normalizeUsdaFood(j);
  assert.equal(f.kind, 'branded'); assert.equal(f.brand, 'Acme'); assert.equal(f.verification, 'imported'); assert.equal(f.confidence, 'moderate');
  assert.deepEqual(f.barcodes, [{ original: '036000291452', gtin14: '00036000291452' }]);
  assert.equal(f.servings[0].grams, 170); assert.equal(f.servings[0].is_default, true); assert.equal(f.servings[0].label, '3/4 cup');
  assert.deepEqual(f.attrs.issues, []); // 59 kcal/100 g x 170 g = 100 kcal: consistent
  const bad = normalizeUsdaFood({ ...j, labelNutrients: { calories: { value: 250 } } });
  assert.equal(bad.verification, 'flagged'); assert.equal(bad.confidence, 'low'); assert.ok(bad.attrs.issues[0].includes('label calories'));
  const bev = normalizeUsdaFood({ ...j, servingSize: 240, servingSizeUnit: 'ml', labelNutrients: undefined });
  assert.equal(bev.basis, 'ml'); assert.equal(bev.servings[0].ml, 240); assert.equal(bev.servings[0].grams, null);
});
test('USDA: implausible values are flagged and quarantined to low confidence', () => {
  const f = normalizeUsdaFood({ ...chicken, foodNutrients: [d(1008, 'Energy', 'kcal', 2400), d(1003, 'Protein', 'g', 31)] });
  assert.equal(f.verification, 'flagged'); assert.equal(f.confidence, 'low');
});
const off = { code: '0036000291452', product_name: 'Greek Yogurt', brands: 'Fage, Total', serving_size: '170 g', serving_quantity: '170', allergens_tags: ['en:milk'], categories_tags: ['en:dairies', 'en:yogurts'],
  nutriments: { 'energy-kcal_100g': 59, proteins_100g: 10.3, carbohydrates_100g: 3.6, fat_100g: 0.4, salt_100g: 0.09 } };
test('Open Food Facts product normalizes; salt becomes calculated sodium; allergens are declared not exhaustive', () => {
  const f = normalizeOffProduct(off);
  assert.equal(f.source_key, 'off'); assert.equal(f.brand, 'Fage'); assert.equal(f.kind, 'branded'); assert.equal(f.verification, 'imported'); assert.equal(f.confidence, 'moderate');
  assert.equal(get(f, 'sodium').per100g, 36); assert.equal(get(f, 'sodium').derivation, 'calculated'); assert.equal(get(f, 'fiber'), undefined);
  assert.deepEqual(f.attrs.allergens_declared, ['milk']); assert.equal(f.servings[0].grams, 170); assert.equal(f.barcodes[0].gtin14, '00036000291452');
  assert.equal(f.category, 'yogurts');
});
test('Open Food Facts: crowdsourced gaps lower confidence; implausible data is flagged; beverages use ml', () => {
  assert.equal(normalizeOffProduct({ ...off, nutriments: { 'energy-kcal_100g': 59 } }).confidence, 'low');
  const bad = normalizeOffProduct({ ...off, nutriments: { 'energy-kcal_100g': 59, proteins_100g: 140, carbohydrates_100g: 3, fat_100g: 1 } });
  assert.equal(bad.verification, 'flagged'); assert.equal(bad.confidence, 'low');
  const bev = normalizeOffProduct({ ...off, serving_size: '250 ml', serving_quantity: 250, quantity: '1 l' });
  assert.equal(bev.basis, 'ml'); assert.equal(bev.servings[0].ml, 250);
});

// HTTP client behavior against mocked fetch (not live).
const res = (status, body) => ({ status, ok: status >= 200 && status < 300, json: async () => body });
test('USDA client: header key, request body, rate-limit and error codes', async () => {
  let seen;
  const f = async (url, init) => { seen = { url, init }; return res(200, { foods: [] }); };
  await usdaSearch({ apiKey: 'K', query: 'cheddar', fetchImpl: f });
  assert.ok(seen.url.endsWith('/foods/search')); assert.equal(seen.init.headers['X-Api-Key'], 'K'); assert.equal(JSON.parse(seen.init.body).query, 'cheddar');
  assert.ok(!seen.url.includes('K'), 'key must not be in the URL');
  await assert.rejects(usdaGetFood({ apiKey: 'K', fdcId: 1, fetchImpl: async () => res(429, {}) }), { code: 'rate_limited' });
  await assert.rejects(usdaGetFood({ apiKey: 'K', fdcId: 1, fetchImpl: async () => res(500, {}) }), { code: 'http_error' });
});
test('Open Food Facts client: user agent required, v3 and v2 shapes, 404 and rate limits', async () => {
  await assert.rejects(offGetProduct({ code: '1', userAgent: '', fetchImpl: async () => res(200, {}) }), /User-Agent/);
  let seen;
  const f3 = async (url, init) => { seen = { url, init }; return res(200, { code: '0036000291452', status: 'success', product: { product_name: 'X' } }); };
  const p = await offGetProduct({ code: '0036000291452', userAgent: 'Macro/0.1 (a@b.c)', fetchImpl: f3 });
  assert.equal(p.product_name, 'X'); assert.equal(seen.init.headers['User-Agent'], 'Macro/0.1 (a@b.c)'); assert.ok(seen.url.includes('/api/v3/product/0036000291452'));
  assert.equal((await offGetProduct({ code: '1', userAgent: 'u', fetchImpl: async () => res(200, { status: 1, product: { product_name: 'Y' } }) })).product_name, 'Y');
  assert.equal(await offGetProduct({ code: '1', userAgent: 'u', fetchImpl: async () => res(404, {}) }), null);
  assert.equal(await offGetProduct({ code: '1', userAgent: 'u', fetchImpl: async () => res(200, { status: 'failure' }) }), null);
  await assert.rejects(offGetProduct({ code: '1', userAgent: 'u', fetchImpl: async () => res(429, {}) }), { code: 'rate_limited' });
  assert.deepEqual(await offSearch({ query: 'oat milk', userAgent: 'u', fetchImpl: async (u) => { assert.ok(u.includes('search_terms=oat+milk')); return res(200, { products: [{ code: '1' }] }); } }), [{ code: '1' }]);
});
