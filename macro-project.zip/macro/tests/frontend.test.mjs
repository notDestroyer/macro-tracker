import test from 'node:test';
import assert from 'node:assert/strict';
import { entryFromCalc, dayTotals, display, provenanceFor } from '../web/lib/diary.js';
import { createApi, debounce } from '../web/lib/api.js';
import { importPhase1, parsePhase1Export } from '../web/lib/import.js';
import { calcItem } from '../web/lib/calc.js';
import { legacySeed } from '../web/lib/legacy-seed.js';

const rice = { id: 'f1', name: 'Rice, white, cooked', kind: 'generic', verification: 'verified', basis: 'g', state: 'cooked', confidence: 'high', source: { key: 'usda_sr_legacy' },
  nutrients: { energy_kcal: 130, protein: 2.7 }, servings: [{ unit: 'cup', amount: 1, grams: 158, confidence: 'moderate' }] };

test('entryFromCalc snapshots only known nutrients, with provenance and weakest-link confidence', () => {
  const qty = { amount: 1, unit: 'cup' }, c = calcItem(rice, qty);
  const e = entryFromCalc(rice, qty, c, { meal: 'Lunch', day: '2026-11-06' });
  assert.deepEqual(e.nutrients, { energy_kcal: 205.4, protein: 4.3 }); assert.ok(!('fiber' in e.nutrients));
  assert.equal(e.provenance, 'verified'); assert.equal(e.confidence, 'moderate'); assert.equal(e.grams, 158); assert.equal(e.food_id, 'f1');
  assert.throws(() => entryFromCalc(rice, qty, { ok: false }, { meal: 'Lunch', day: 'd' }));
  assert.equal(provenanceFor({ source: { key: 'legacy_seed' } }), 'legacy_seed'); assert.equal(provenanceFor({ kind: 'user' }), 'user'); assert.equal(provenanceFor({ verification: 'flagged' }), 'imported');
  const milk = { ...rice, basis: 'ml', servings: [] }; const mc = calcItem(milk, { amount: 1, unit: 'cup' });
  assert.equal(entryFromCalc(milk, { amount: 1, unit: 'cup' }, mc, { meal: 'Lunch', day: 'd' }).grams, null);
});
test('day totals never turn unknown into zero', () => {
  const t = dayTotals([{ meal: 'Lunch', nutrients: { energy_kcal: 300, sodium: 500 } }, { meal: 'Lunch', nutrients: { energy_kcal: 200 } }, { meal: 'Snacks', nutrients: { energy_kcal: 100, sodium: 0 } }]);
  assert.equal(t.totals.energy_kcal, 600); assert.deepEqual(display('sodium', t), { known: true, value: 500, atLeast: true });
  assert.deepEqual(display('fiber', t), { known: false, value: null, atLeast: false }); assert.deepEqual(display('energy_kcal', t), { known: true, value: 600, atLeast: false });
  assert.equal(t.byMeal.Lunch.totals.energy_kcal, 500); assert.equal(t.byMeal.Dinner.totals.energy_kcal, undefined);
});
test('API client: auth headers, error mapping, local cache, online bypass', async () => {
  let calls = 0, last, status = 200, clock = 0;
  const fetchImpl = async (url, init) => { calls++; last = { url, init }; return { ok: status < 300, status, json: async () => (status < 300 ? { results: [] } : { error: 'x' }) }; };
  const api = createApi({ supabaseUrl: 'https://p.supabase.co', anonKey: 'ANON', getToken: async () => 'JWT', fetchImpl, now: () => clock });
  await api.searchFoods('Rice'); await api.searchFoods('rice'); assert.equal(calls, 1);
  assert.equal(last.url, 'https://p.supabase.co/functions/v1/search-foods'); assert.equal(last.init.headers.Authorization, 'Bearer JWT'); assert.equal(last.init.headers.apikey, 'ANON');
  clock = 61000; await api.searchFoods('rice'); assert.equal(calls, 2);
  await api.searchFoods('rice', { online: true }); assert.equal(JSON.parse(last.init.body).online, true); await api.searchFoods('rice'); assert.equal(calls, 4);
  status = 429; await assert.rejects(api.lookupBarcode('036000291452'), { code: 'rate_limited' });
  status = 401; await assert.rejects(api.foodDetail('x'), { code: 'unauthorized' });
  await assert.rejects(createApi({ supabaseUrl: 'u', anonKey: 'a', getToken: async () => null, fetchImpl }).searchFoods('x'), { code: 'unauthorized' });
});
test('debounce runs once, with the last arguments', async () => {
  const seen = []; const d = debounce((x) => { seen.push(x); return x; }, 20);
  d(1); d(2); const last = d(3);
  assert.equal(await last, 3); await new Promise((r) => setTimeout(r, 40)); assert.deepEqual(seen, [3]);
});

// Minimal in-memory stand-in for the supabase-js query builder (select/like/eq/range/upsert).
function fakeSupabase(foods) {
  const db = { foods, log_entries: [], user_profiles: [], water_logs: [] };
  const from = (t) => { let rows = db[t], op = null, rng = null, payload, opts;
    const b = { select: () => b, like: (c, p) => { rows = rows.filter((r) => String(r[c]).startsWith(p.replace('%', ''))); return b; }, eq: (c, v) => { rows = rows.filter((r) => r[c] === v); return b; },
      range: (a, z) => { rng = [a, z]; return b; }, upsert: (p, o) => { op = 'u'; payload = p; opts = o; return b; },
      then: (res) => { if (op) { const ks = opts.onConflict.split(','); for (const r of [].concat(payload)) { const i = db[t].findIndex((x) => ks.every((k) => x[k] === r[k] && r[k] != null)); if (i < 0) db[t].push({ ...r }); else if (!opts.ignoreDuplicates) db[t][i] = { ...db[t][i], ...r }; } return res({ data: null, error: null }); }
        return res({ data: rng ? rows.slice(rng[0], rng[1] + 1) : rows, error: null }); } };
    return b; };
  return { db, from };
}
const seedFoods = legacySeed.map((s) => ({ id: `uuid-${s.i}`, source_ref: `seed:${s.i}` }));
const mkEntry = (i, g, id, day = '2026-11-02') => { const f = legacySeed[i], m = (k) => Math.round((f[k] * g / 100) * 10) / 10; return { id, meal: 'Lunch', fid: i, n: f.name, q: g, u: 'g', g, k: m('kcal'), p: m('p'), c: m('c'), f: m('f'), fi: m('fi'), na: m('na') }; };
const exportText = (extra = {}) => JSON.stringify({ profile: { age: 30 }, targets: { kcal: 2000 }, water: { '2026-11-02': 474 },
  log: { '2026-11-02': [mkEntry(0, 150, 'a'), mkEntry(12, 200, 'b'), { id: 'c', meal: 'Snacks', n: 'Quick add', q: '', u: 'quick add', g: 0, k: 250, p: 0, c: 0, f: 0, fi: 0, na: 0 }], '2026-11-03': [mkEntry(30, 118, 'd', '2026-11-03')] }, ...extra });

test('Phase 1 import: permanent ids, unknowns preserved, idempotent, verified by read-back', async () => {
  const sb = fakeSupabase(seedFoods);
  const r = await importPhase1(sb, 'user-1', exportText());
  assert.equal(r.ok, true, JSON.stringify(r)); assert.equal(r.imported, 4); assert.deepEqual(r.verification.dayMismatches, []);
  const rows = sb.db.log_entries;
  assert.equal(rows.find((x) => x.legacy_id === 'b').food_id, 'uuid-12'); assert.equal(rows.find((x) => x.legacy_id === 'c').food_id, null);
  assert.deepEqual(rows.find((x) => x.legacy_id === 'c').nutrients, { energy_kcal: 250 }); assert.ok(rows.every((x) => x.user_id === 'user-1'));
  assert.equal(sb.db.user_profiles.length, 1); assert.deepEqual(sb.db.water_logs, [{ user_id: 'user-1', day: '2026-11-02', ml: 474 }]);
  const again = await importPhase1(sb, 'user-1', exportText()); assert.equal(again.ok, true); assert.equal(sb.db.log_entries.length, 4, 'second import must not duplicate');
  sb.db.user_profiles[0].profile = { age: 31 }; await importPhase1(sb, 'user-1', exportText()); assert.equal(sb.db.user_profiles[0].profile.age, 31, 'existing profile is not overwritten');
});
test('Phase 1 import refuses bad input and integrity failures without writing', async () => {
  const sb = fakeSupabase(seedFoods);
  assert.equal((await importPhase1(sb, 'u', 'nope')).reason, 'not_json'); assert.equal((await importPhase1(sb, 'u', '{"log":[]}')).reason, 'not_a_phase1_export');
  assert.equal(parsePhase1Export('{"log":{"d":5}}').reason, 'not_a_phase1_export');
  const bad = JSON.parse(exportText()); bad.log['2026-11-02'][0].fid = 5;
  const r = await importPhase1(sb, 'u', JSON.stringify(bad)); assert.equal(r.reason, 'integrity_mismatches'); assert.equal(sb.db.log_entries.length, 0);
  assert.equal((await importPhase1(fakeSupabase(seedFoods.slice(0, 40)), 'u', exportText())).reason, 'seed_foods_missing');
  assert.equal((await importPhase1(sb, 'u', JSON.stringify(bad), { force: true })).imported, 4);
});
test('Phase 1 import handles a large history (paged read-back)', async () => {
  const log = { '2026-01-01': Array.from({ length: 1300 }, (_, i) => mkEntry(i % 51, 100, `big${i}`, '2026-01-01')) };
  const sb = fakeSupabase(seedFoods); const r = await importPhase1(sb, 'u', JSON.stringify({ log }));
  assert.equal(r.ok, true); assert.equal(r.verification.found, 1300);
});
