// Static checks on the migrations. They do NOT execute SQL (no Postgres in the build environment); applying them is verified separately.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { NUTRIENTS, SOURCES } from '../supabase/functions/_shared/reference.js';

const dir = new URL('../supabase/migrations/', import.meta.url);
const files = readdirSync(dir).filter((f) => f.endsWith('.sql')).sort();
const sql = Object.fromEntries(files.map((f) => [f, readFileSync(new URL(f, dir), 'utf8')]));
const all = Object.values(sql).join('\n');
const noComments = (s) => s.replace(/--.*$/gm, '');

test('migrations exist in order', () => assert.equal(files.length, 4));
test('every table has Row Level Security enabled', () => {
  const tables = [...noComments(all).matchAll(/create table public\.(\w+)/g)].map((m) => m[1]);
  assert.ok(tables.length >= 15);
  for (const t of tables) assert.ok(new RegExp(`alter table public\\.${t} enable row level security`).test(all), `RLS missing on ${t}`);
});
test('user-owned tables are scoped to auth.uid()', () => {
  for (const t of ['log_entries', 'recipes', 'estimates', 'user_corrections', 'user_profiles', 'water_logs'])
    assert.ok(new RegExp(`create policy own_rows on public\\.${t} for all to authenticated using \\(user_id = auth\\.uid\\(\\)\\) with check \\(user_id = auth\\.uid\\(\\)\\)`).test(all), t);
  assert.ok(!/create policy [^;]*to anon/.test(all), 'no policy may grant anon access');
  assert.ok(!/create policy [^;]*to public/.test(all));
});
test('security definer functions pin search_path and are locked down', () => {
  for (const m of all.matchAll(/create or replace function ([\w.]+)\([\s\S]*?security definer([^$]*)\$\$/g)) assert.ok(/set search_path/.test(m[0]), m[1]);
  for (const fn of ['ingest_food(jsonb)', 'consume_quota(text, int, int)']) {
    assert.ok(all.includes(`revoke all on function public.${fn} from public, anon, authenticated;`), fn);
    assert.ok(all.includes(`grant execute on function public.${fn} to service_role;`), fn);
  }
});
test('reference data migration matches reference.js', () => {
  const ref = sql[files[1]];
  for (const n of NUTRIENTS) assert.ok(ref.includes(`(${n.id}, '${n.key}', `), n.key);
  for (const s of SOURCES) assert.ok(ref.includes(`('${s.key}', `), s.key);
  assert.equal([...ref.matchAll(/^\((\d+), '/gm)].length, NUTRIENTS.length);
});
test('unknown is representable and zero is never defaulted', () => {
  assert.ok(/per100g numeric not null/.test(all)); assert.ok(!/per100g numeric[^,]*default 0/.test(all));
  assert.ok(/nutrients jsonb not null check \(jsonb_typeof\(nutrients\) = 'object'\)/.test(all));
});
test('no destructive statements; quotes and parentheses balance', () => {
  assert.ok(!/\bdrop table\b|\btruncate table\b|\bdrop schema\b/i.test(noComments(all)));
  for (const [f, s] of Object.entries(sql)) {
    const body = noComments(s);
    assert.equal((body.match(/\(/g) || []).length, (body.match(/\)/g) || []).length, `${f}: parentheses`);
    assert.equal((body.match(/'/g) || []).length % 2, 0, `${f}: single quotes`);
    assert.equal((body.match(/\$\$/g) || []).length % 2, 0, `${f}: $$ blocks`);
  }
});
test('legacy seed inserts are idempotent', () => {
  const l = sql[files[3]]; assert.equal((l.match(/on conflict/g) || []).length, 2); assert.ok(l.includes('where not exists'));
});
