import test from 'node:test';
import assert from 'node:assert/strict';
import { toBasisAmount, canonUnit, unitKind, G_PER_OZ } from '../supabase/functions/_shared/units.js';
import { calcItem } from '../supabase/functions/_shared/calc.js';

const near = (a, b, tol = 1e-6) => assert.ok(Math.abs(a - b) <= tol, `${a} is not within ${tol} of ${b}`);
const rice = { basis: 'g', state: 'cooked', confidence: 'high', nutrients: { energy_kcal: 130, protein: 2.7 },
  servings: [{ label: '1 cup', amount: 1, unit: 'cup', modifier: '', grams: 158, state: 'cooked', confidence: 'moderate' }] };

test('mass units convert exactly', () => {
  const g = (amount, unit) => toBasisAmount({ basis: 'g' }, { amount, unit }).amount;
  near(g(1, 'oz'), 28.349523125); near(g(2, 'lb'), 907.18474); near(g(250, 'mg'), 0.25); near(g(1.5, 'kg'), 1500); near(g(180, 'g'), 180);
  assert.equal(toBasisAmount({ basis: 'g' }, { amount: 1, unit: 'oz' }).confidence, 'high');
  near(G_PER_OZ, 28.349523125);
});
test('unit aliases', () => {
  assert.equal(canonUnit('Tbsp.'), 'tbsp'); assert.equal(canonUnit('fl oz'), 'floz'); assert.equal(canonUnit('pieces'), 'each');
  assert.equal(canonUnit('Cups'), 'cup'); assert.equal(unitKind('handful'), 'ambiguous'); assert.equal(unitKind('slice'), 'count');
});
test('cup uses the food-specific serving weight (cooked rice, 158 g per cup)', () => {
  const r = (a) => toBasisAmount(rice, { amount: a, unit: 'cup' });
  near(r(1).amount, 158); near(r(0.5).amount, 79); near(r(2).amount, 316);
  assert.equal(r(1).method, 'serving_match'); assert.equal(r(1).confidence, 'moderate');
});
test('tablespoons derive from the food\'s own cup portion, not from water', () => {
  const pb = { basis: 'g', servings: [{ unit: 'cup', amount: 1, grams: 258, confidence: 'moderate' }] };
  near(toBasisAmount(pb, { amount: 1, unit: 'tbsp' }).amount, 258 / 16, 1e-4);
  assert.equal(toBasisAmount(pb, { amount: 1, unit: 'tbsp' }).method, 'serving_density');
});
test('volume with no density data is refused rather than guessed', () => {
  const r = toBasisAmount({ basis: 'g', servings: [{ unit: 'slice', grams: 28 }] }, { amount: 1, unit: 'cup' });
  assert.equal(r.ok, false); assert.equal(r.reason, 'needs_density');
  assert.equal(toBasisAmount({ basis: 'g' }, { amount: 100, unit: 'ml' }).reason, 'needs_density');
});
test('raw and cooked are never crossed', () => {
  assert.equal(toBasisAmount(rice, { amount: 1, unit: 'cup' }, { state: 'raw' }).reason, 'state_mismatch');
  const pasta = { basis: 'g', state: null, servings: [
    { unit: 'cup', amount: 1, grams: 105, state: 'dry', confidence: 'high' }, { unit: 'cup', amount: 1, grams: 140, state: 'cooked', confidence: 'high' }] };
  near(toBasisAmount(pasta, { amount: 1, unit: 'cup' }, { state: 'cooked' }).amount, 140);
  near(toBasisAmount(pasta, { amount: 1, unit: 'cup' }, { state: 'dry' }).amount, 105);
});
test('modifier selects chopped vs whole and unmatched modifiers are disclosed', () => {
  const sp = { basis: 'g', servings: [{ unit: 'cup', amount: 1, modifier: 'chopped', grams: 30 }, { unit: 'cup', amount: 1, modifier: 'whole leaves', grams: 22 }] };
  near(toBasisAmount(sp, { amount: 1, unit: 'cup' }, { modifier: 'chopped' }).amount, 30);
  near(toBasisAmount(sp, { amount: 1, unit: 'cup' }, { modifier: 'whole' }).amount, 22);
  const noMod = toBasisAmount(sp, { amount: 1, unit: 'cup' });
  assert.ok(noMod.assumptions.some((a) => a.includes('Several portions')));
  assert.ok(toBasisAmount(sp, { amount: 1, unit: 'cup' }, { modifier: 'packed' }).assumptions.some((a) => a.includes('packed')));
});
test('counts, servings and ambiguous units', () => {
  const bread = { basis: 'g', servings: [{ unit: 'slice', amount: 1, grams: 28, confidence: 'high', is_default: false }, { unit: 'serving', amount: 1, grams: 56, is_default: true }] };
  near(toBasisAmount(bread, { amount: 2, unit: 'slices' }).amount, 56);
  near(toBasisAmount(bread, { amount: 1, unit: 'serving' }).amount, 56);
  const none = toBasisAmount(bread, { amount: 1, unit: 'handful' });
  assert.equal(none.reason, 'ambiguous_quantity'); assert.ok(none.suggestions.length);
  const almonds = { basis: 'g', servings: [{ unit: 'handful', amount: 1, grams: 28, confidence: 'high' }] };
  assert.equal(toBasisAmount(almonds, { amount: 1, unit: 'handful' }).confidence, 'low');
  assert.equal(toBasisAmount(bread, { amount: 1, unit: 'scoop' }).reason, 'no_serving_for_unit');
});
test('ml-basis foods (beverages)', () => {
  const milk = { basis: 'ml', servings: [{ unit: 'serving', amount: 1, grams: 244, ml: 236.5882365, is_default: true }] };
  near(toBasisAmount(milk, { amount: 1, unit: 'cup' }).amount, 236.5882365);
  const oz = toBasisAmount(milk, { amount: 12, unit: 'oz' });
  near(oz.amount, 12 * 29.5735295625); assert.ok(oz.assumptions[0].includes('fluid'));
  near(toBasisAmount(milk, { amount: 100, unit: 'g' }).amount, 100 / (244 / 236.5882365), 1e-6);
  assert.equal(toBasisAmount({ basis: 'ml', servings: [] }, { amount: 100, unit: 'g' }).reason, 'needs_density');
});
test('bad amounts', () => {
  for (const a of [0, -1, NaN, 'x', null]) assert.equal(toBasisAmount(rice, { amount: a, unit: 'cup' }).reason, 'bad_amount');
});
test('calcItem scales nutrients and confidence is the weakest link', () => {
  const r = calcItem(rice, { amount: 1, unit: 'cup' }, { identification: 'exact' });
  near(r.nutrients.energy_kcal, 130 * 1.58); near(r.nutrients.protein, 2.7 * 1.58);
  assert.equal(r.nutrients.fiber, undefined, 'unknown nutrient must stay unknown');
  assert.equal(r.confidence, 'moderate'); // portion is moderate even though food is high
  assert.equal(calcItem({ ...rice, confidence: 'high' }, { amount: 100, unit: 'g' }).confidence, 'high');
  assert.equal(calcItem({ ...rice, confidence: 'high' }, { amount: 100, unit: 'g' }, { identification: 'close' }).confidence, 'moderate');
  assert.equal(calcItem({ ...rice, confidence: 'low' }, { amount: 100, unit: 'g' }).confidence, 'low');
  assert.equal(calcItem(rice, { amount: 1, unit: 'cup' }, { state: 'raw' }).ok, false);
});
