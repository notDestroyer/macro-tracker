import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { migratePhase1 } from '../supabase/functions/_shared/legacy.js';
import { legacySeed } from '../supabase/functions/_shared/legacy-seed.js';

// Reproduces exactly how Phase 1 wrote a diary entry (grams rounded to whole numbers, values rounded to 1 decimal).
const phase1Entry = (i, g, id) => { const f = legacySeed[i], m = (k) => Math.round((f[k] * g / 100) * 10) / 10;
  return { id, meal: 'Lunch', fid: i, n: f.name, q: g, u: 'g', g: Math.round(g), k: m('kcal'), p: m('p'), c: m('c'), f: m('f'), fi: m('fi'), na: m('na') }; };

test('legacy seed is the frozen Phase 1 list', () => {
  assert.equal(legacySeed.length, 51); assert.equal(legacySeed[0].name, 'Egg, whole, boiled');
  assert.equal(new Set(legacySeed.map((s) => s.name)).size, 51);
  legacySeed.forEach((s, i) => assert.equal(s.i, i));
});
test('every Phase 1 food migrates to its permanent reference with no mismatches', () => {
  const log = { '2026-11-02': legacySeed.map((s, i) => phase1Entry(i, 37 + i * 13.7, `e${i}`)) };
  const out = migratePhase1({ profile: { age: 30 }, targets: { kcal: 2000 }, log, water: { '2026-11-02': 711 } }, legacySeed);
  assert.equal(out.entries.length, 51); assert.equal(out.report.entries, 51); assert.deepEqual(out.report.mismatches, []);
  out.entries.forEach((e, i) => {
    assert.equal(e.legacy_ref, `seed:${i}`); assert.equal(e.name, legacySeed[i].name); assert.equal(e.provenance, 'legacy_seed'); assert.equal(e.confidence, 'low');
    assert.equal(e.legacy_id, `e${i}`); assert.ok('fiber' in e.nutrients && 'sodium' in e.nutrients);
  });
  assert.deepEqual(out.water, [{ day: '2026-11-02', ml: 711 }]); assert.deepEqual(out.profile, { age: 30 }); assert.deepEqual(out.targets, { kcal: 2000 });
});
test('quick-add: fiber and sodium become unknown; blank macros become unknown; entered macros are kept', () => {
  const state = { log: { '2026-11-02': [
    { id: 'a', meal: 'Snacks', n: 'Quick add', q: '', u: 'quick add', g: 0, k: 300, p: 0, c: 0, f: 0, fi: 0, na: 0 },
    { id: 'b', meal: 'Snacks', n: 'Protein bar', q: '', u: 'quick add', g: 0, k: 210, p: 20, c: 22, f: 7, fi: 0, na: 0 }] } };
  const [a, b] = migratePhase1(state, legacySeed).entries;
  assert.deepEqual(a.nutrients, { energy_kcal: 300 }); assert.equal(a.legacy_ref, null); assert.equal(a.provenance, 'user'); assert.equal(a.quantity, null); assert.equal(a.grams, null);
  assert.deepEqual(b.nutrients, { energy_kcal: 210, protein: 20, carb_total: 22, fat_total: 7 });
  assert.ok(!('fiber' in b.nutrients) && !('sodium' in b.nutrients));
});
test('integrity checks catch a shifted index, a bad index and wrong calories', () => {
  const e = phase1Entry(3, 100, 'x');
  const shifted = migratePhase1({ log: { d: [{ ...e, fid: 4 }] } }, legacySeed).report.mismatches;
  assert.equal(shifted.length >= 1, true); assert.ok(shifted[0].problem.includes(legacySeed[4].name));
  assert.ok(migratePhase1({ log: { d: [{ ...e, fid: 99 }] } }, legacySeed).report.mismatches[0].problem.includes('no seed'));
  assert.ok(migratePhase1({ log: { d: [{ ...e, k: e.k + 80 }] } }, legacySeed).report.mismatches[0].problem.includes('calories'));
});
test('migration is deterministic and does not mutate its input', () => {
  const log = { d: [phase1Entry(10, 85, 'z'), phase1Entry(20, 100, 'y')] };
  const before = JSON.stringify(log);
  assert.deepEqual(migratePhase1({ log }, legacySeed), migratePhase1({ log }, legacySeed)); assert.equal(JSON.stringify(log), before);
});
test('empty or partial exports do not crash', () => {
  const out = migratePhase1({}, legacySeed); assert.deepEqual(out.entries, []); assert.equal(out.report.entries, 0);
});
test('SQL seed gives every Phase 1 index the same permanent uuid the code expects', () => {
  const sql = readFileSync(new URL('../supabase/migrations/20261103000004_legacy_seed.sql', import.meta.url), 'utf8');
  const uuid = (i) => { const b = createHash('sha1').update(`macro-legacy-seed:${i}`).digest().subarray(0, 16); b[6] = (b[6] & 0x0f) | 0x50; b[8] = (b[8] & 0x3f) | 0x80; const h = b.toString('hex'); return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`; };
  const pairs = [...sql.matchAll(/\('([0-9a-f-]{36})', '(?:[^']|'')*', '(?:[^']|'')*', (?:'\w+'|null), 'seed:(\d+)'/g)];
  assert.equal(pairs.length, 51);
  for (const [, id, i] of pairs) assert.equal(id, uuid(Number(i)));
  assert.equal(new Set(pairs.map((p) => p[1])).size, 51);
  assert.ok(/'unverified', 'low'/.test(sql) && /'estimated'/.test(sql));
});
