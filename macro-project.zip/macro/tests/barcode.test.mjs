import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeGtin, validGtin, gs1CheckDigit, upcEtoUpcA } from '../supabase/functions/_shared/barcode.js';

test('check digits', () => {
  assert.equal(gs1CheckDigit('03600029145'), 2); assert.equal(gs1CheckDigit('400638133393'), 1); assert.equal(gs1CheckDigit('9638507'), 4);
  for (const c of ['036000291452', '4006381333931', '96385074', '012345678905']) assert.ok(validGtin(c), c);
  assert.ok(!validGtin('036000291453'));
});
test('UPC-A and the same product as EAN-13 resolve to one 14-digit code', () => {
  const a = normalizeGtin('012345678905'), b = normalizeGtin('0012345678905');
  assert.equal(a.gtin14, '00012345678905'); assert.equal(a.gtin14, b.gtin14);
  assert.equal(a.candidates[0].type, 'UPC-A'); assert.equal(b.candidates[0].type, 'EAN-13');
  assert.equal(normalizeGtin('4006381333931').gtin14, '04006381333931');
  assert.equal(normalizeGtin(' 0 36000-29145 2 ').gtin14, '00036000291452');
});
test('UPC-E expands to UPC-A, and 8-digit codes keep both readings', () => {
  assert.equal(upcEtoUpcA('01234565'), '012345000065');
  const r = normalizeGtin('01234565');
  assert.equal(r.candidates[0].type, 'UPC-E'); assert.equal(r.candidates[0].gtin14, '00012345000065');
  assert.ok(r.candidates.some((c) => c.type === 'EAN-8'));
  const e = normalizeGtin('96385074'); assert.equal(e.candidates[0].type, 'EAN-8'); assert.equal(e.gtin14, '00000096385074');
});
test('rejects bad input', () => {
  assert.equal(normalizeGtin('036000291453').reason, 'bad_check_digit');
  assert.equal(normalizeGtin('abc').reason, 'not_numeric');
  assert.equal(normalizeGtin('12345').reason, 'bad_length');
  assert.equal(normalizeGtin('').ok, false);
});
