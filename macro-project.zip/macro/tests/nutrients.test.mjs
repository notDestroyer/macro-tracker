import test from 'node:test';
import assert from 'node:assert/strict';
import { mapUsdaNutrients, mapOffNutriments, plausibilityIssues, scaleNutrients, sumNutrients, toMap } from '../supabase/functions/_shared/nutrients.js';
import { checkAtwater, expectedKcal } from '../supabase/functions/_shared/atwater.js';

const d = (id, name, unitName, amount) => ({ nutrient: { id, name, unitName }, amount });
const get = (r, k) => r.nutrients.find((n) => n.key === k);

test('USDA detail shape maps by id with unit and name verification', () => {
  const r = mapUsdaNutrients([d(1008, 'Energy', 'kcal', 165), d(1003, 'Protein', 'g', 31), d(1093, 'Sodium, Na', 'mg', 74), d(9999, 'Mystery', 'g', 1)]);
  assert.equal(get(r, 'energy_kcal').per100g, 165); assert.equal(get(r, 'sodium').per100g, 74);
  assert.equal(r.ignored.length, 1); assert.equal(r.warnings.length, 0);
});
test('USDA search shape maps too, with uppercase units', () => {
  const r = mapUsdaNutrients([{ nutrientId: 1008, nutrientName: 'Energy', unitName: 'KCAL', value: 52 }, { nutrientId: 1106, nutrientName: 'Vitamin A, RAE', unitName: 'UG', value: 3 }]);
  assert.equal(get(r, 'energy_kcal').per100g, 52); assert.equal(get(r, 'vit_a_rae').per100g, 3);
});
test('a wrong unit or name on a known id is reported, not silently mapped', () => {
  const r = mapUsdaNutrients([d(1008, 'Energy', 'kJ', 690), d(1003, 'Fructose', 'g', 5)]);
  assert.equal(r.nutrients.length, 0); assert.equal(r.warnings.length, 2);
});
test('missing stays unknown, reported zero stays zero', () => {
  const r = mapUsdaNutrients([d(1008, 'Energy', 'kcal', 155), d(1079, 'Fiber, total dietary', 'g', 0), d(1003, 'Protein', 'g', null)]);
  assert.equal(get(r, 'fiber').per100g, 0);
  assert.equal(get(r, 'protein'), undefined);
  assert.equal(get(r, 'sodium'), undefined);
});
test('energy prefers 1008, falls back to Atwater variants, never averages', () => {
  const both = mapUsdaNutrients([d(2047, 'Energy (Atwater General Factors)', 'kcal', 200), d(1008, 'Energy', 'kcal', 190)]);
  assert.equal(both.nutrients.filter((n) => n.key === 'energy_kcal').length, 1); assert.equal(get(both, 'energy_kcal').per100g, 190);
  assert.equal(get(mapUsdaNutrients([d(2047, 'Energy (Atwater General Factors)', 'kcal', 200)]), 'energy_kcal').per100g, 200);
  const dup = mapUsdaNutrients([d(1003, 'Protein', 'g', 10), d(1003, 'Protein', 'g', 30)]);
  assert.equal(get(dup, 'protein').per100g, 10);
});
test('Open Food Facts: grams to mg, kJ to kcal, salt to sodium only when sodium is absent', () => {
  const r = mapOffNutriments({ 'energy-kcal_100g': 61, proteins_100g: '3.2', carbohydrates_100g: 4.8, fat_100g: 3.3, sodium_100g: 0.4, calcium_100g: 0.12, salt_100g: 9 });
  assert.equal(get(r, 'sodium').per100g, 400); assert.equal(get(r, 'sodium').derivation, 'reported');
  assert.ok(Math.abs(get(r, 'calcium').per100g - 120) < 1e-9); assert.equal(get(r, 'protein').per100g, 3.2);
  const salt = mapOffNutriments({ salt_100g: 1 });
  assert.equal(get(salt, 'sodium').per100g, 400); assert.equal(get(salt, 'sodium').derivation, 'calculated');
  const kj = mapOffNutriments({ energy_100g: 418.4 });
  assert.ok(Math.abs(get(kj, 'energy_kcal').per100g - 100) < 1e-9); assert.equal(get(kj, 'energy_kcal').derivation, 'calculated');
});
test('Open Food Facts: absent, blank and invalid values are unknown; real zero is kept', () => {
  const r = mapOffNutriments({ 'energy-kcal_100g': 10, fiber_100g: '', sugars_100g: 'n/a', fat_100g: 0, 'trans-fat_100g': -1 });
  assert.equal(get(r, 'fiber'), undefined); assert.equal(get(r, 'sugars_total'), undefined);
  assert.equal(get(r, 'fat_total').per100g, 0); assert.equal(get(r, 'fat_trans'), undefined); assert.equal(r.warnings.length, 1);
});
test('plausibility gate', () => {
  assert.deepEqual(plausibilityIssues({ energy_kcal: 165, protein: 31, fat_total: 3.6, carb_total: 0 }), []);
  assert.ok(plausibilityIssues({ protein: 120 }).length);
  assert.ok(plausibilityIssues({ energy_kcal: 1200 }).length);
  assert.ok(plausibilityIssues({ protein: 50, carb_total: 40, fat_total: 30 }).length);
  assert.ok(plausibilityIssues({ carb_total: 10, sugars_total: 20 }).length);
  assert.ok(plausibilityIssues({ fat_total: 5, fat_sat: 9 }).length);
});
test('scaling and summing keep unknown unknown and report partial totals', () => {
  const sc = scaleNutrients({ energy_kcal: 130, protein: 2.7 }, 158);
  assert.ok(Math.abs(sc.energy_kcal - 205.4) < 1e-9 && Math.abs(sc.protein - 4.266) < 1e-9 && Object.keys(sc).length === 2);
  const { totals, partial } = sumNutrients([{ energy_kcal: 100, sodium: 50 }, { energy_kcal: 200 }, { energy_kcal: 50, sodium: 0 }]);
  assert.equal(totals.energy_kcal, 350); assert.equal(totals.sodium, 50); assert.deepEqual(partial, { sodium: 1 });
  assert.equal(totals.fiber, undefined);
  assert.deepEqual(toMap([{ key: 'a', per100g: 1 }]), { a: 1 });
});
test('Atwater check flags only large disagreements and never edits values', () => {
  assert.equal(checkAtwater(155, { protein: 12.6, carb_total: 1.1, fat_total: 10.6 }).status, 'ok');
  assert.equal(checkAtwater(379, { protein: 13.2, carb_total: 67.7, fat_total: 6.5, fiber: 10.1 }).status, 'ok');
  assert.equal(checkAtwater(300, { protein: 12.6, carb_total: 1.1, fat_total: 10.6 }).status, 'flag');
  assert.equal(checkAtwater(10, { protein: 1, carb_total: 4, fat_total: 0 }).status, 'ok'); // small absolute gap
  assert.equal(checkAtwater(155, { protein: 12.6, fat_total: 10.6 }).status, 'insufficient');
  assert.ok(Math.abs(expectedKcal({ protein: 10, carb_total: 10, fat_total: 10, alcohol: 10 }) - 240) < 1e-9);
  const macros = { protein: 12.6, carb_total: 1.1, fat_total: 10.6 }; const before = JSON.stringify(macros);
  checkAtwater(300, macros); assert.equal(JSON.stringify(macros), before);
});
