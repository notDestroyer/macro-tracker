// Copies the browser-safe shared modules to web/lib so the frontend uses exactly the code the tests cover.
import { readdirSync, copyFileSync, mkdirSync } from 'node:fs';
const src = new URL('../supabase/functions/_shared/', import.meta.url), dst = new URL('../web/lib/', import.meta.url);
mkdirSync(dst, { recursive: true });
for (const f of readdirSync(src).filter((f) => f.endsWith('.js'))) copyFileSync(new URL(f, src), new URL(f, dst));
console.log('synced shared modules to web/lib');
