// Live smoke test for the USDA and Open Food Facts adapters. Run on your machine with real access:
//   USDA_API_KEY=... OFF_USER_AGENT="MacroTracker/0.1 (you@example.com)" node scripts/smoke.mjs
// It calls the real APIs, runs the real normalizers, checks the results, and writes smoke-report.json.
// Paste the console output (or the JSON file) back so the integrations can be marked verified or fixed.
import { writeFileSync } from 'node:fs';
import { usdaSearch, usdaGetFood, normalizeUsdaFood } from '../supabase/functions/_shared/usda.js';
import { offGetProduct, offSearch, normalizeOffProduct } from '../supabase/functions/_shared/off.js';
import { checkAtwater } from '../supabase/functions/_shared/atwater.js';
import { toMap, plausibilityIssues } from '../supabase/functions/_shared/nutrients.js';
import { calcItem } from '../supabase/functions/_shared/calc.js';

const { USDA_API_KEY, OFF_USER_AGENT } = process.env;
const report = { when: new Date().toISOString(), checks: [] };
const check = (name, pass, detail = '') => { report.checks.push({ name, pass, detail }); console.log(`${pass ? 'PASS' : 'FAIL'}  ${name}${detail ? '  ' + detail : ''}`); };
const guard = async (name, fn) => { try { await fn(); } catch (e) { check(name, false, `threw: ${e.message}`); } };

async function usda() {
  if (!USDA_API_KEY) return check('USDA: configured', false, 'USDA_API_KEY not set');
  const cases = [['cheddar cheese', 'generic'], ['white rice cooked', 'generic'], ['greek yogurt', 'any']];
  for (const [q] of cases) await guard(`USDA search "${q}"`, async () => {
    const res = await usdaSearch({ apiKey: USDA_API_KEY, query: q, pageSize: 10 });
    check(`USDA search "${q}" returns foods`, Array.isArray(res.foods) && res.foods.length > 0, `${res.foods?.length} hits, first dataType ${res.foods?.[0]?.dataType}`);
    const norm = res.foods.map((j) => normalizeUsdaFood(j));
    const withEnergy = norm.filter((f) => f.nutrients.some((n) => n.key === 'energy_kcal'));
    check(`USDA "${q}": energy mapped on most hits`, withEnergy.length >= Math.ceil(norm.length / 2), `${withEnergy.length}/${norm.length}`);
    const warn = norm.flatMap((f) => f.attrs.mapping_warnings);
    check(`USDA "${q}": no id/unit/name mapping warnings`, warn.length === 0, warn.length ? JSON.stringify(warn.slice(0, 3)) : '');
    report[`usda_${q}`] = { first: norm[0] && { name: norm[0].name, type: norm[0].attrs.data_type, nutrients: norm[0].nutrients.length } };
  });
  await guard('USDA detail (portions)', async () => {
    const res = await usdaSearch({ apiKey: USDA_API_KEY, query: 'cheddar cheese', pageSize: 5, dataTypes: ['Foundation', 'SR Legacy'] });
    const hit = res.foods?.[0]; check('USDA: a Foundation/SR Legacy hit exists', !!hit, hit?.description);
    if (!hit) return;
    const full = normalizeUsdaFood(await usdaGetFood({ apiKey: USDA_API_KEY, fdcId: hit.fdcId }));
    const m = toMap(full.nutrients);
    check('USDA detail: nutrients mapped', full.nutrients.length >= 8, `${full.nutrients.length} nutrients; unmapped ids ignored: ${full.attrs.unmapped_count}`);
    check('USDA detail: no mapping warnings', full.attrs.mapping_warnings.length === 0, JSON.stringify(full.attrs.mapping_warnings.slice(0, 3)));
    check('USDA detail: portions parsed', full.servings.length > 0, JSON.stringify(full.servings.slice(0, 3).map((s) => `${s.amount} ${s.unit} ${s.modifier} = ${s.grams} g`)));
    check('USDA detail: plausible values', plausibilityIssues(m).length === 0, plausibilityIssues(m).join('; '));
    const at = checkAtwater(m.energy_kcal, { protein: m.protein, carb_total: m.carb_total, fat_total: m.fat_total, fiber: m.fiber });
    check('USDA detail: Atwater consistent', at.status !== 'flag', JSON.stringify(at));
    const cup = full.servings.find((s) => s.unit === 'cup');
    if (cup) { const r = calcItem({ ...full, nutrients: m }, { amount: 1, unit: 'cup' }); check('USDA: one cup converts using this food\'s own portion', r.ok, r.ok ? `${Math.round(r.amount)} g, ${Math.round(r.nutrients.energy_kcal)} kcal, confidence ${r.confidence}` : r.reason); }
    report.usda_detail_sample = full;
  });
}

async function off() {
  if (!OFF_USER_AGENT) return check('OFF: configured', false, 'OFF_USER_AGENT not set');
  await guard('OFF barcode', async () => {
    const p = await offGetProduct({ code: '3017620422003', userAgent: OFF_USER_AGENT }); // Nutella 400 g, a widely listed product
    check('OFF: known barcode found', !!p, p?.product_name);
    if (!p) return;
    const f = normalizeOffProduct(p);
    check('OFF: name and brand parsed', !!f.name && !!f.brand, `${f.brand} / ${f.name}`);
    check('OFF: core nutrients mapped', ['energy_kcal', 'protein', 'fat_total', 'carb_total'].every((k) => f.nutrients.some((n) => n.key === k)), f.nutrients.map((n) => n.key).join(','));
    check('OFF: barcode normalized', f.barcodes[0]?.gtin14 === '03017620422003', JSON.stringify(f.barcodes));
    check('OFF: plausible values', f.attrs.issues.length === 0, f.attrs.issues.join('; '));
    report.off_sample = f;
  });
  await new Promise((r) => setTimeout(r, 7000)); // stay under the 10 searches/min limit
  await guard('OFF search', async () => {
    const list = await offSearch({ query: 'oat milk', userAgent: OFF_USER_AGENT, pageSize: 5 });
    check('OFF: search returns products', list.length > 0, `${list.length} products`);
    const norm = list.map((p) => normalizeOffProduct(p));
    check('OFF: search products normalize', norm.every((f) => f.source_ref), `${norm.filter((f) => f.nutrients.length).length}/${norm.length} with nutrition data`);
  });
}

await usda(); await off();
const failed = report.checks.filter((c) => !c.pass).length;
writeFileSync(new URL('../smoke-report.json', import.meta.url), JSON.stringify(report, null, 1));
console.log(`\n${report.checks.length - failed}/${report.checks.length} checks passed. Report written to smoke-report.json`);
process.exit(failed ? 1 : 0);
